from django.contrib import admin

from .models import Users, Employee, \
    Equipment, Shift


# Register your models here.
admin.site.register(Users)
admin.site.register(Employee)
admin.site.register(Equipment)
admin.site.register(Shift)
