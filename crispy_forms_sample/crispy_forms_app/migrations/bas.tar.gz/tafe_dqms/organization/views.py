from django.shortcuts import render, render_to_response
from django.template import RequestContext
from django.template.response import TemplateResponse
from django.views.generic.list import ListView
from django.views.generic.edit import UpdateView
from django.http import JsonResponse
from django.views.generic import View
from django.core import serializers

from control_plan.models import StagingServer
from .models import Users, Employee, Equipment, Shift
from .forms import ResetForm, RoleSelectForm, DeviationReasonForm
from login.views import LoginRequiredMixin, get_user_dict


class ModelListView(LoginRequiredMixin, ListView):
    model = None
    Headers = None
    fields_order = None
    template_name = 'organization/list.html'

    def get_object(self, queryset=None):
        return queryset.get(
            model=self.model,
            Headers=self.Headers,
            fields_order=self.fields_order
        )

    def get_context_data(self, **kwargs):
        context = super(ModelListView, self).get_context_data(**kwargs)
        context['Headers'] = self.Headers
        context['fields_order'] = self.fields_order
        context['title'] = self.model.__name__
        context['object_list'] = self.get_model_table_data()
        return context

    def get_model_table_data(self):
        fields = self.fields_order
        fields.append('id')
        if self.model == Employee:
            return self.model.objects.filter(
                users__stagingserver__supplier__vendor_code=self.request.session[
                    'uid'],
                is_active=True
            ).order_by('last_modified_date').reverse(
            ).values(*fields)
        else:
            return self.model.objects.filter(
                stagingserver__supplier__vendor_code=self.request.session[
                    'uid'],
                is_active=True
            ).order_by('last_modified_date').reverse(
            ).values(*fields)


class ModelCreateView(LoginRequiredMixin, View):
    model = None
    form_class = None
    redirect_url = None

    def get_object(self, queryset=None):
        return queryset.get(
            model=self.model,
            form_class=self.form_class,
            redirect_url=self.redirect_url
        )

    def get(self, request):
        if self.model == Employee and 'stagingserver' in request.GET:
            content = self.render_to_template(request, self.form_class(
                stagingserver=request.GET['stagingserver'],
                user=request.session['uid']
            ))
        else:
            content = self.render_to_template(request, self.form_class(
                user=request.session['uid']))
        response = {'status': 0, 'content': content}
        return JsonResponse(response, safe=False)

    def post(self, request):
        form = self.form_class(
            request.POST,
            user=request.session['uid'])
        if form.is_valid():
            form.save()
            response = {'status': 1, 'redirect_url': self.redirect_url}
            return JsonResponse(response, safe=True)
        else:
            content = self.render_to_template(request, form)
            response = {
                'status': 0,
                'content': content,
                'fields': ['#' +
                           field for field in self.form_class.Meta.fields]
            }
            return JsonResponse(response, safe=True)

    def render_to_template(self, request, form):
        template = TemplateResponse(request, 'organization/create.html', {
            'form': form,
            'url': 'create/',
            'tr_id': 'addNew',
        })
        template.render()
        return template.content


class ModelUpdateView(LoginRequiredMixin, View):
    model = None
    form_class = None
    redirect_url = None

    def get_object(self, queryset=None):
        return queryset.get(
            model=self.model,
            form_class=self.form_class,
            redirect_url=self.redirect_url
        )

    def get(self, request):
        model_obj = self.model.objects.values(
            *self.form_class.Meta.fields).get(id=request.GET['id'])
        form = self.form_class(
            model_obj,
            pk=request.GET['id'],
            type=None,
            user=request.session['uid']
        )
        content = self.render_to_template(
            request, form, request.GET['id'])
        response = {'status': 0, 'content': content}
        return JsonResponse(response, safe=True)

    def post(self, request):
        form = self.form_class(
            request.POST, pk=request.POST['pk'],
            type=request.POST['type'],
            user=request.session['uid']
        )
        if form.is_valid():
            form.save()
            response = {'status': 1, 'redirect_url': self.redirect_url}
            return JsonResponse(response, safe=True)
        else:
            content = self.render_to_template(
                request, form, request.POST['pk'])
            response = {
                'status': 0,
                'content': content,
                'fields': ['#' + field
                           for field in self.form_class.Meta.fields]
            }
            return JsonResponse(response, safe=True)

    def render_to_template(self, request, form, pk):
        model_obj = self.model.objects.get(id=pk)
        template = TemplateResponse(request, 'organization/create.html', {
            'form': form,
            'url': 'update/',
            'tr_id': str(model_obj.name) + str(pk),
            'id': pk,
        })
        template.render()
        return template.content


class ModelDeleteView(LoginRequiredMixin, View):
    model = None
    redirect_url = None

    def get_object(self, queryset=None):
        return queryset.get(
            model=self.model,
            redirect_url=self.redirect_url
        )

    def get(self, request):
        model_obj = self.model.objects.get(id=request.GET['id'])
        model_obj.is_active = False
        model_obj.save()
        response = {'status': 1, 'redirect_url': self.redirect_url}
        return JsonResponse(response, safe=False)


class UsersView(LoginRequiredMixin, View):
    template_name = 'organization/users_list.html'

    def get(self, request):
        if 'stagingserver' not in request.GET:
            form = RoleSelectForm(user=get_user_dict(request))
            return render(request, self.template_name, {
                'reset_form': form,
            })
        else:
            form = RoleSelectForm(
                user=get_user_dict(request),
                stagingserver=request.GET['stagingserver'],
            )
            template = TemplateResponse(
                request, 'organization/users/filterform.html', {
                    'reset_form': form
                })
            template.render()
            return JsonResponse(template.content, safe=False)


class ResetView(LoginRequiredMixin, View):

    def get(self, request):
        form = ResetForm()
        template = TemplateResponse(
            request, 'organization/reset_form.html', {
                'form': form,
                'pk': request.GET['id']
            })
        template.render()
        return JsonResponse(template.content, safe=False)

    def post(self, request):
        form = ResetForm(request.POST, pk=request.POST['pk'])
        if form.is_valid():
            form.reset()
            return JsonResponse('Password reseted successfully.', safe=False)
        else:
            template = TemplateResponse(
                request, 'organization/reset_form.html', {
                    'form': form,
                    'pk': request.POST['pk']
                })
            template.render()
            return JsonResponse(template.content, safe=False)


class DeviationReasonsUpdate(UpdateView):
    model = StagingServer
    form_class = DeviationReasonForm
    template_name = 'organization/deviation/deviation_update.html'

    def get_object(self):
        try:
            return self.model.objects.get(
                supplier__vendor_code=self.request.session["uid"])
        except StagingServer.DoesNotExist:
            return self.model.objects.none()

    def get_absolute_url(self):
        return "/organization/deviation_reason/"

    def post(self, request):
        try:
            deviation_reasons = request.POST["deviation_reasons"]
            deviation_reasons_list = deviation_reasons.split(',')
            modified_deviation_reasons_list = []
            for deviation in deviation_reasons_list:
                if deviation != "":
                    modified_deviation_reasons_list.append(deviation)
            stagingserver = StagingServer.objects.get(
                supplier__vendor_code=self.request.session["uid"])
            stagingserver.deviation_reasons = ','.join(
                modified_deviation_reasons_list)
            stagingserver.save()
            return JsonResponse("Updated Successfully", safe=False)
        except StagingServer.DoesNotExist:
            return JsonResponse("StagingServer does not exist.", safe=False)
