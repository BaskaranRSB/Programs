from django.conf.urls import url

from .models import Shift, Equipment, Employee
from .forms import ShiftForm, EquipmentForm, EmployeeForm
from .views import ModelListView, ModelCreateView, ModelUpdateView, ModelDeleteView,\
    UsersView, ResetView, DeviationReasonsUpdate


urlpatterns = [
    url(r'^shift/$', ModelListView.as_view(
        model=Shift,
        Headers=['Location', 'Shift Id',
                 'Shift Name', 'Start Time',
                 'End Time'],
        fields_order=['stagingserver__area_code', 'shift_id',
                      'name', 'start_time', 'end_time'])),
    url(r'^shift/create/$', ModelCreateView.as_view(
        model=Shift,
        form_class=ShiftForm,
        redirect_url='/organization/shift/')),
    url(r'^shift/update/$', ModelUpdateView.as_view(
        model=Shift,
        form_class=ShiftForm,
        redirect_url='/organization/shift/')),
    url(r'shift/delete/$',
        ModelDeleteView.as_view(
            model=Shift,
            redirect_url='/organization/shift/')),
]

urlpatterns += [
    url(r'^equipment/$', ModelListView.as_view(
        model=Equipment,
        Headers=['Location', 'Equipment Id',
                 'Equipment Name', 'Is Active'],
        fields_order=['stagingserver__area_code', 'supplier_equipment_id',
                      'name', 'is_active'])),
    url(r'^equipment/create/$', ModelCreateView.as_view(
        model=Equipment,
        form_class=EquipmentForm,
        redirect_url='/organization/equipment/')),
    url(r'^equipment/update/$', ModelUpdateView.as_view(
        model=Equipment,
        form_class=EquipmentForm,
        redirect_url='/organization/equipment/')),
    url(r'equipment/delete/$', ModelDeleteView.as_view(
        model=Equipment,
        redirect_url='/organization/equipment/')),
]

urlpatterns += [
    url(r'^employee/$', ModelListView.as_view(
        model=Employee,
        Headers=['Location', 'Employee Id', 'Employee Name',
                 'Role', 'Is Active'],
        fields_order=['users__stagingserver__area_code',
                      'supplier_employee_id', 'name',
                      'users__role', 'is_active'])),
    url(r'^employee/create/$', ModelCreateView.as_view(
        model=Employee,
        form_class=EmployeeForm,
        redirect_url='/organization/employee/')),
    url(r'^employee/update/$', ModelUpdateView.as_view(
        model=Employee,
        form_class=EmployeeForm,
        redirect_url='/organization/employee/')),
    url(r'employee/delete/$', ModelDeleteView.as_view(
        model=Employee,
        redirect_url='/organization/employee/')),
]

urlpatterns += [
    url(r'^role/$', UsersView.as_view(), name='role_list'),
    url(r'^role/resetpassword/$',
        ResetView.as_view(),
        name='role_select'),
]

urlpatterns += [
    url(r'^deviation_reason/$', DeviationReasonsUpdate.as_view(),
        name='deviation_reason_detail'),
]
