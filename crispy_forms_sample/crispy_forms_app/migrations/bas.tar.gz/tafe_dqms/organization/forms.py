from collections import OrderedDict

from django import forms
from django.views.generic.edit import FormView
from django.utils.translation import ugettext_lazy as _

from .models import Shift, Equipment, Employee, Users
from control_plan.models import StagingServer


def get_kwargs(*args, **kwargs):
    if 'pk' in kwargs and 'type' in kwargs:
        return kwargs.pop('pk'), kwargs.pop('type')
    else:
        return None, None


def deactivate_model_object(model, pk):
    model_obj = model.objects.get(id=pk)
    model_obj.is_active = False
    model_obj.save()
    return model_obj


def activate_model_object(model_obj):
    model_obj.is_active = True
    model_obj.is_updated = True
    model_obj.save()
    return model_obj


def order_form_fields(fields_list, fields_dict):
    sorted_dict = OrderedDict()
    for field in fields_list:
        sorted_dict[field] = fields_dict[field]
    return sorted_dict


class ShiftForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        self.pk, self.type = get_kwargs(*args, **kwargs)
        super(ShiftForm, self).__init__(*args)
        self.fields["stagingserver"].queryset = StagingServer.objects.filter(
            supplier__vendor_code=user)
        if self.pk and self.type is None:
            for field in ['stagingserver', 'shift_id', 'name']:
                self.fields[field].widget.attrs = {
                    'class': 'form-control'}
        elif self.pk is None:
            for field in ['stagingserver', 'shift_id', 'name']:
                self.fields[field].required = True
                self.fields[field].widget.attrs = {
                    'class': 'form-control'}
        else:
            self.fields['shift_id'].initial = self.pk
            for field in ['stagingserver', 'shift_id', 'name']:
                self.fields[field].required = True
                self.fields[field].widget.attrs = {
                    'class': 'form-control'}
        self.fields['start_time'].widget = forms.TimeInput(
            attrs={'class': 'form-control'},
            format='%H:%m')
        self.fields['end_time'].widget = forms.TimeInput(
            attrs={'class': 'form-control'},
            format='%H:%m')

    def save(self, *args, **kwargs):
        if self.pk:
            model_obj = deactivate_model_object(Shift, self.pk)
            return super(ShiftForm, self).save(*args, **kwargs)
        else:
            return super(ShiftForm, self).save(*args, **kwargs)

    class Meta:
        model = Shift
        fields = ['stagingserver', 'shift_id',
                  'name', 'start_time', 'end_time']
        labels = {field_label: _(field_label)
                  for field_label in fields}


class EquipmentForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        self.pk, self.type = get_kwargs(*args, **kwargs)
        super(EquipmentForm, self).__init__(*args)
        self.fields["stagingserver"].queryset = StagingServer.objects.filter(
            supplier__vendor_code=user)
        for fields in ['stagingserver', 'name',
                       'supplier_equipment_id', 'is_active']:
            self.fields[fields].widget.attrs = {
                'class': 'form-control'}

    def save(self, *args, **kwargs):
        if self.pk:
            if self.cleaned_data["is_active"] == False:
                equipment = Equipment.objects.get(id=self.pk)
                equipment.is_active = False
                return equipment.save()
            else:
                model_obj = deactivate_model_object(Equipment, self.pk)
                model_obj.pk = None
                model_obj.name = self.cleaned_data['name']
                model_obj.supplier_equipment_id = self.cleaned_data[
                    'supplier_equipment_id']
                model_obj.stagingserver = self.cleaned_data['stagingserver']
                return activate_model_object(model_obj)
        else:
            return super(EquipmentForm, self).save(*args, **kwargs)

    class Meta:
        model = Equipment
        fields = ['stagingserver', 'supplier_equipment_id',
                  'name', 'is_active']
        labels = {field_label: _(field_label)
                  for field_label in fields}


class StagingServerChoiceField(forms.ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s" % obj.area_code


class EmployeeForm(forms.ModelForm):
    stagingserver = StagingServerChoiceField(
        queryset=StagingServer.objects.none(),
        required=True)

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        self.pk, self.type = get_kwargs(*args, **kwargs)
        if 'stagingserver' in kwargs:
            self.stagingserver = kwargs.pop('stagingserver')
        else:
            self.stagingserver = None
        super(EmployeeForm, self).__init__(*args)
        field_order = ['stagingserver', 'supplier_employee_id',
                       'name', 'users', 'is_active']
        self.fields['stagingserver'].empty_label = "Select Staging Server"
        self.fields["stagingserver"].queryset = StagingServer.objects.filter(
            supplier__vendor_code=user)
        self.fields = order_form_fields(field_order, self.fields)
        if self.pk is None and self.type is None and \
                self.stagingserver is not None:
            self.fields['users'].queryset = Users.objects.filter(
                stagingserver=self.stagingserver)
            self.fields['stagingserver'] = StagingServerChoiceField(
                queryset=StagingServer.objects.all(),
                initial={'id': self.stagingserver})
        if self.pk is not None and self.type is None:
            stagingserver_id = Users.objects.get(
                id=self.data['users']).stagingserver
            self.fields['stagingserver'] = StagingServerChoiceField(
                queryset=StagingServer.objects.all(),
                initial={'id': stagingserver_id})
            self.fields['users'].queryset = Users.objects.filter(
                stagingserver=stagingserver_id)
        for field in ['stagingserver', 'name',
                      'supplier_employee_id', 'users', 'is_active']:
            if field == 'stagingserver':
                self.fields[field].widget.attrs = {
                    'id': 'stagingserver_id', 'class': 'form-control'}
            else:
                self.fields[field].widget.attrs = {
                    'class': 'form-control'}
        if self.stagingserver:
            self.fields['stagingserver'].initial = self.stagingserver

    def save(self, *args, **kwargs):
        if self.pk:
            if self.cleaned_data["is_active"] == False:
                employee = Employee.objects.get(id=self.pk)
                employee.is_active = False
                return employee.save()
            else:
                model_obj = deactivate_model_object(Employee, self.pk)
                model_obj.pk = None
                model_obj.name = self.cleaned_data['name']
                model_obj.supplier_employee_id = self.cleaned_data[
                    'supplier_employee_id']
                model_obj.users = self.cleaned_data['users']
                return activate_model_object(model_obj)
        else:
            return super(EmployeeForm, self).save(*args, **kwargs)

    class Meta:
        model = Employee
        fields = ['supplier_employee_id', 'name',
                  'users', 'is_active']
        labels = {field_label: _(field_label)
                  for field_label in fields}


class ResetForm(forms.Form):
    new_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True)
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True)

    def __init__(self, *args, **kwargs):
        if kwargs:
            self.pk = kwargs.pop('pk')
        super(ResetForm, self).__init__(*args, **kwargs)

    def clean(self):
        cleaned_data = super(ResetForm, self).clean()
        new_password = cleaned_data.get("new_password")
        confirm_password = cleaned_data.get("confirm_password")
        if new_password != confirm_password:
            raise forms.ValidationError(
                "Password Does Not Match.")

    def reset(self, *args, **kwargs):
        users = Users.objects.get(id=self.pk)
        users.password = self.cleaned_data['new_password']
        return users.save()


class RoleChoiceField(forms.ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s" % obj.role


class RoleSelectForm(forms.Form):
    location = StagingServerChoiceField(
        queryset=StagingServer.objects.none())

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        if 'stagingserver' in kwargs:
            self.stagingserver = kwargs.pop('stagingserver')
        else:
            self.stagingserver = None
        super(RoleSelectForm, self).__init__(*args, **kwargs)
        if self.stagingserver:
            self.fields['location'] = StagingServerChoiceField(
                queryset=StagingServer.objects.filter(
                    supplier__vendor_code=user["uid"]),
                initial={'id': self.stagingserver})
            self.fields['role'] = RoleChoiceField(
                queryset=Users.objects.filter(
                    stagingserver=self.stagingserver))
        self.fields['location'].queryset = StagingServer.objects.filter(
            supplier__vendor_code=user["uid"])


class DeviationReasonForm(forms.ModelForm):

    class Meta:
        model = StagingServer
        fields = ['deviation_reasons']
        help_texts = {
            'deviation_reasons': _('Text should be a comma seperated value.'),
        }
