from __future__ import unicode_literals
import binascii
import os

from django.utils import timezone
from django.db import models
from django.utils.encoding import python_2_unicode_compatible
from django.db.models import signals

from control_plan.models import StagingServer, save_updated_table
from tafe_dqms.settings.dev import DEFAULT_KEY_VALIDITY_DURATION


# Create your models here.


@python_2_unicode_compatible
class Users(models.Model):
    """docstring for ClassName"""

    role = models.CharField(max_length=60, blank=True,
                            null=True, unique=False)
    stagingserver = models.ForeignKey(
        StagingServer, on_delete=models.CASCADE)
    password = models.CharField(max_length=100)
    key = models.CharField(max_length=40, unique=True, editable=False)
    key_expiry_date = models.DateTimeField(blank=True, editable=False)
    is_updated = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    last_modified_date = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Users'
        unique_together = ('role', 'stagingserver')

    def is_authenticated(self):
        return True

    def is_anonymous(self):
        return False

    def save(self, *args, **kwargs):
        if not self.key:
            self.generate_key()

        if not self.key_expiry_date:
            self.calculate_new_expiration()

        return super(Users, self).save(*args, **kwargs)

    def calculate_new_expiration(self):
        validity_duration = DEFAULT_KEY_VALIDITY_DURATION
        self.key_expiry_date = timezone.now() + validity_duration

    @property
    def is_expired(self):
        return self.key_expiry_date < timezone.now()

    def generate_key(self):
        self.key = binascii.hexlify(os.urandom(20)).decode()

    def __str__(self):
        return self.role

signals.post_save.connect(save_updated_table, sender=Users)


class Employee(models.Model):
    """docstring for ClassName"""
    name = models.CharField(max_length=60, verbose_name="Employee Name",
                            unique=False)
    supplier_employee_id = models.CharField(
        max_length=60, verbose_name="Employee Id", unique=False)
    users = models.ForeignKey(
        Users, on_delete=models.CASCADE, verbose_name="Role")
    is_active = models.BooleanField(default=True)
    is_updated = models.BooleanField(default=False)
    last_modified_date = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Employee'

    def __str__(self):
        return self.name

signals.post_save.connect(save_updated_table, sender=Employee)


class Equipment(models.Model):
    """docstring for Equipment"""
    name = models.CharField(
        max_length=60, verbose_name="Equipment Name", unique=False)
    supplier_equipment_id = models.CharField(
        max_length=60, verbose_name="Equipment Id", unique=False)
    stagingserver = models.ForeignKey(
        StagingServer, on_delete=models.CASCADE, verbose_name="Location")
    is_active = models.BooleanField(default=True, verbose_name="Is Active")
    is_updated = models.BooleanField(default=False)
    last_modified_date = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Equipment'

signals.post_save.connect(save_updated_table, sender=Equipment)


class Shift(models.Model):
    """docstring for Shift"""
    shift_id = models.CharField(max_length=60, verbose_name="Shift ID",
                                unique=False)
    name = models.CharField(max_length=60, verbose_name="Shift Name",
                            null=True, blank=True, unique=False)
    start_time = models.TimeField(verbose_name="Start Time", unique=False)
    end_time = models.TimeField(verbose_name="End Time", unique=False)
    stagingserver = models.ForeignKey(StagingServer, on_delete=models.CASCADE,
                                      verbose_name="Location")
    is_active = models.BooleanField(default=True, verbose_name="Is Active")
    is_updated = models.BooleanField(default=False)
    last_modified_date = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'Shift'

signals.post_save.connect(save_updated_table, sender=Shift)
