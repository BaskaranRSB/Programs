import logging

from django.core.management.base import BaseCommand, CommandError
from django.db import connection, OperationalError

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = 'Creates the custom application view'

    def add_arguments(self, parser):
        parser.add_argument('--view', nargs='*')

    def handle(self, *args, **options):
        for view_name in options["view"]:
            if view_name == "RejectionReport":
                self.create_RejectionReport()
            elif view_name == "CharacteristicsData":
                self.create_CharacteristicsData()
            else:
                self.stdout.write("Can't create a view named {0}".format(
                    view_name))

    def create_RejectionReport(self):
        try:
            cursor = connection.cursor()
            cursor.execute('''CREATE View RejectionReport AS
            select reject.rejection_date Date,
            Month(reject.rejection_date) `Month`,

            grin.vendor_code `Supplier Code`,

            sup.vendor_name `Supplier Name`,

            grin.part_code `Part No`,

            prt.description `Part Description`,

            plant_code `Plant`,

            grin_quantity `GRIN Closed Qty`,

            CASE part_type WHEN 'A5' THEN part_qty ELSE 0 END `A5 Qty`,

            CASE part_type WHEN 'A1' THEN part_qty ELSE 0 END `A1 QTY`,

            CASE part_type WHEN 'N7' THEN part_qty ELSE 0 END `N7 QTY`,

            CASE part_type WHEN 'A2' THEN part_qty ELSE 0 END `A2 QTY`,

            CASE part_type WHEN 'A6' THEN part_qty ELSE 0 END `A6 QTY`,

            CASE part_type WHEN 'N9' THEN part_qty ELSE 0 END `N9 QTY`,

            (grin_quantity / batch_quantity) * 1000000 PPM

            from grin_data grin inner join parts_qty_rejection reject on
            grin.part_code=reject.part_code and
            grin.vendor_code=reject.vendor_code

            inner join Part prt on grin.part_code=prt.tafe_part_id

            inner join Supplier sup on grin.vendor_code=sup.vendor_code
            ''')
            self.stdout.write("RejectionReport View created successfully")
        except OperationalError as e:
            logger.info(e)

    def create_CharacteristicsData(self):
        try:
            cursor = connection.cursor()
            cursor.execute('''CREATE VIEW `CharacteristicsData` AS
            select `b`.`id` AS `Batch_Id`,`b`.`batch_start_date`
            AS `Batch_Date`,`ic`.`characteristics_id` AS
            `Characteristics_Id`,`ic`.`measured_value` AS
            `Measured_Value`,`ic`.`mode_toggle` AS
            `Mode_Toggle`,`samp`.`history` AS `History`,`samp`.`sample_category`
            AS `sample_category` from
            (((`InspectionCharacteristics` `ic` join `Characteristics` `c`
            on((`ic`.`characteristics_id` = `c`.`id`))) join
            `InspectionSamples` `samp` on((`ic`.`inspection_samples_id` = `samp`.`id`)))
            join `Batch` `b` on((`samp`.`batch_id` = `b`.`id`)))
            order by batch_start_date, `ic`.`characteristics_id`,cast(replace(`samp`.`id`,concat(`samp`.`batch_id`,'-'),'') as unsigned)
            ''')
            self.stdout.write("CharacteristicsData View created successfully")
        except OperationalError as e:
            logger.info(e)
