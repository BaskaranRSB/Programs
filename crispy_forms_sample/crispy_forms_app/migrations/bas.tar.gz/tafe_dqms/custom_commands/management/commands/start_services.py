from threading import Thread
import logging

from django.core.management.base import BaseCommand, CommandError
from table_refresh.table_refresh import refresh_masterdata
from soap.soap_post import soap_post

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = 'Starts the services'

    def handle(self, *args, **options):
        t1 = Thread(target=refresh_masterdata, args=(1, ))
        t2 = Thread(target=soap_post, args=(10, ))
        logger.info("Starting Table Refresh service.")
        t1.start()
        logger.info("Starting SOAP POST service.")
        t2.start()
