from django import template

from authentication.models import DqmsUser
from django.contrib.auth.models import Permission
from django.apps import apps

register = template.Library()


@register.filter(name='check_perms')
def check_perms(user, codename):
    try:
        user = DqmsUser.objects.get(user=user)
        if codename in user.user_permissions.all().values_list("codename", flat=True):
            return True
        else:
            return False
    except DqmsUser.DoesNotExist:
        return True


@register.filter(name='check_supplier')
def check_supplier(user):
    user = DqmsUser.objects.get(user=user)
    return user.is_supplier_group


@register.filter(name='check_access')
def check_access(user, screen_name):
    user = DqmsUser.objects.get(user=user)
    if user.is_supplier_group:
        if screen_name in ["Control Plan Screen", "Serial No Search Screen",
                           "Control Plan Upload", "Control Plan Download"]:
            return False
    return True
