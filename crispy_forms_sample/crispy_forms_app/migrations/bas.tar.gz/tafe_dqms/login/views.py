import json
from collections import OrderedDict

from django.contrib.auth.models import Permission
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.views.generic import View
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.template.response import TemplateResponse

from .forms import LoginForm, PermissionMatrixFilterForm
from authentication.authentication import LdapAuthentication
from .models import MainScreen, SubScreen
from authentication.models import DqmsUser


def get_user_dict(request):
    """
    Returns the dictionary of session variables.
    """
    return {
        "uid": request.session["uid"],
        "role": request.session["user"],
        "is_supplier_group": DqmsUser.objects.get(
            user=request.session["user"]).is_supplier_group
    }


class LoginRequiredMixin(object):
    """
    View mixin which verifies that the user has authenticated.

    NOTE:
        This should be the left-most mixin of a view.
    """

    def dispatch(self, *args, **kwargs):
        try:
            user = self.request.session['uid']
            return super(LoginRequiredMixin, self).dispatch(*args, **kwargs)
        except KeyError:
            return HttpResponse('please login')


class LoginView(View):

    def get(self, request, *args, **kwargs):
        if 'loginCode' in request.GET:
            form = LoginForm(initial={'username': request.GET['loginCode']})
            delete_all_session(request)
            return render(request, 'login.html', {'form': form})
        else:
            return HttpResponse('URL parameters are wrong')

    def post(self, request, *args, **kwargs):
        request.session.set_expiry(60000)
        form = LoginForm(request.POST, user=request.GET['loginRole'])
        response_status = {}
        if form.is_valid():
            request.session['uid'], request.session[
                'user'] = request.GET['loginCode'], request.GET['loginRole']
            if request.session['user'] == 'Vendor':
                response_status.update({
                    'status': 1,
                    'redirect_url': '/inspection/list/'
                })
            else:
                response_status.update({
                    'status': 1,
                    'redirect_url': '/control/plan/'
                })
        else:
            response_status.update({
                'status': 0,
                'error': form.errors
            })
        return JsonResponse(response_status)


class PermissionMatrix(View):
    form_class = PermissionMatrixFilterForm

    def get(self, request):
        form = self.form_class()
        return render(request, 'admin/permission/matrix.html', {
            'form': form,
        })

    def post(self, request):
        user_group = self.get_user_group(request)
        screens = self.get_screens(request)
        table_dict = self.get_table_dict(
            user_group, screens)
        response = render_to_template(
            request,
            "admin/permission/matrix_table.html",
            {
                "table_data": table_dict
            }
        )
        return JsonResponse(response, safe=False)

    def get_user_group(self, request):
        if "user_group" not in request.POST:
            user = DqmsUser.objects.all()
            return user.values("id", "user")
        else:
            return DqmsUser.objects.filter(
                id__in=request.POST.getlist("user_group")
            ).values("id", "user")

    def get_screens(self, request):
        if "screens" not in request.POST:
            screen = SubScreen.objects.all()
        else:
            screen = SubScreen.objects.filter(
                id__in=request.POST.getlist("screens")
            )
        return screen.values(
            "id", "sub_screen_name",
            "main_screen__screen_name",
            "permission__codename"
        )

    def get_table_dict(self, user_list, sub_screen_list):
        _dict = {
            "table_header": ["Screens"] + [user["user"] for user in user_list],
            "table_body": {}
        }
        for sub_screen in sub_screen_list:
            if sub_screen["main_screen__screen_name"] not in _dict["table_body"].keys():
                _dict["table_body"].update({
                    sub_screen["main_screen__screen_name"]: []
                })
                _dict["table_body"][sub_screen["main_screen__screen_name"]].append({
                    "sub_screen_id": sub_screen["id"],
                    "sub_screen_name": sub_screen["sub_screen_name"],
                    "user_list": user_list,
                    "codename": sub_screen["permission__codename"]
                })
            else:
                _dict["table_body"][sub_screen["main_screen__screen_name"]].append({
                    "sub_screen_id": sub_screen["id"],
                    "sub_screen_name": sub_screen["sub_screen_name"],
                    "user_list": user_list,
                    "codename": sub_screen["permission__codename"]
                })
        return _dict


def render_to_template(request, template_name, args):
    template = TemplateResponse(request, template_name, args)
    template.render()
    return template.content


def set_permission(request):
    user = DqmsUser.objects.get(id=int(request.POST["user_id"]))
    screen = SubScreen.objects.get(id=int(request.POST["screen_id"]))
    if request.POST["status"] != "0":
        user.user_permissions.add(screen.permission)
        response = "Permission added for User {0}".format(user.user)
    else:
        user.user_permissions.remove(screen.permission)
        response = "Permission removed for User {0}".format(user.user)
    return JsonResponse(response, safe=False)


def logout_view(request):
    logout(request)
    return redirect("http://www.google.com")


def delete_all_session(request):
    for key in request.session.keys():
        del request.session[key]
