function batch_wise_cp_cpk(data, output_div_id){
  var cp = data.cp;
  var cpk = data.cpk;
  var ticks = data.ticks;
        plot2 = $.jqplot(output_div_id, [cp, cpk], {
            seriesDefaults: {
                renderer:$.jqplot.BarRenderer,
                rendererOptions:  {barWidth:10},
                pointLabels: { show: true }
            },
            axes: {
                xaxis: {
                    renderer: $.jqplot.CategoryAxisRenderer,
                    ticks: ticks
                }
            }
        });
}

function plot_batch_ppm(data, output_div_id){
        $.jqplot.config.enablePlugins = true;
        var s1 = data.ppm_list;
        var characteristics_name_list = data.characteristics_name_list;

        plot1 = $.jqplot(output_div_id, [s1], {
            // Only animate if we're not using excanvas (not in IE 7 or IE 8)..
            animate: !$.jqplot.use_excanvas,
            seriesDefaults:{
                renderer:$.jqplot.BarRenderer,
                rendererOptions:  {barWidth:10},
                pointLabels: { show: true }
            },
            axes: {
                xaxis: {
                    renderer: $.jqplot.CategoryAxisRenderer,
                    ticks: characteristics_name_list
                }
            },
            highlighter: { show: false},
             
            });

        $('#chart1').bind('jqplotDataClick',
            function (ev, seriesIndex, pointIndex, data) {
                $('#info1').html('series: '+seriesIndex+', point: '+pointIndex+', data: '+data);
            }
        );
}

function draw_pie_chart(data, output_div_id){
  if(data.length != 0){
    $.jqplot(output_div_id, [data], {
    /*title: 'Pie Chart with Tooltips',*/
    seriesDefaults: {
      renderer: $.jqplot.PieRenderer,
      rendererOptions: {
        showDataLabels: true,
        padding: 10,
        sliceMargin: 6,
        shadow: false
      }
    },
    legend: {
      show: true
    },
    highlighter: {
      show: true,
      useAxesFormatters: false,
      tooltipFormatString: '%s'
    }
 
  });
  }
  else{
    $('#'+output_div_id).attr("align", "center").html("No defects were found.");
  }
}


function plot_P_NP_Chart(p_bar_list, ucl_list, p_list, lcl_list){
// Plot Chart Start
try{
  console.log("Plotting P Chart...");
  console.log(ucl_list, lcl_list);
  var plot2 = $.jqplot('chart1', [p_list, ucl_list, lcl_list], {
      title:'p Chart',
      seriesDefaults: {
        breakOnNull:true,
      },
      axes:{
        xaxis:{
          renderer:$.jqplot.DateAxisRenderer,
          tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
          tickOptions:{
            formatString:'%b %#d',
            showGridline: false,
            angle: -90,
          },
          tickInterval:'1 day'
        },
        yaxis:{
          tickRenderer: $.jqplot.CanvasAxisTickRenderer,
          tickOptions:{
            showGridline: false,
            formatString: "%#.4f"
          },
        }
      },
      highlighter: {
          show: true,
      },
      legend:{
        show:true,
        location:'ne',
        placement:'inside',
        fontSize:'8px',
        labels: ["p", "UCL", "LCL"],
        rendererOptions: {
            numberRows: 1
        },
      },
      series:[
        {
          lineWidth:4,
          markerOptions:{
            style:'square'
          }
        }
      ],
      cursor: {
          show: true,
          zoom: true,
      },
      grid: {
          backgroundColor: '#FFFFFF'
      }
  });
  console.log("Chart plotted.");
}
catch(error){
  console.log(error.message);
  if(error.message == "No data specified"){
    alert("No data retrived for selected options.");
  }
}
}


function plotControlAndRangeChart(controlAndRangeDataSet, control_div_id = "", range_div_id = "") {
    if(control_div_id == ""){
      control_div_id = 'chart1'
      range_div_id = 'chart2'
    }
    try {

        console.log(controlAndRangeDataSet);
        // controlChartData
        var controlChartXLabel = '';
        var controlChartYLabel = '';
        var controlChartXMin = 0;
        var controlChartYMin = 0;
        var controlChartXMax = 0;
        var controlChartYMax = 0;
        var controlChartYInterval = 0;
        var uclx = [];
        var lclx = [];
        var avgXBar = [];

        // rangeChartData,
        grid: {
            backgroundColor: '#FFFFFF'
        }
        var rangeChartXLabel = '';
        var rangeChartYLabel = '';
        var rangeChartXMin = 0;
        var rangeChartYMin = 0;
        var rangeChartXMax = 0;
        var rangeChartYMax = 0;
        var rangeChartYInterval = 0;
        var uclr = [];
        var uclx = [];
        var range = [];



        // get Control Chart Data
        var controlChartData = controlAndRangeDataSet.controlChartData,
        uclx = controlChartData.uclx;
        lclx = controlChartData.lclx;
        avgXBar = controlChartData.avgXBar;
        controlChartXLabel = controlChartData.xLabel;
        controlChartYLabel = controlChartData.yLabel;
        controlChartXMin = 1;
        var min_data = getMinOfArray(lclx);
        var max_data = getMaxOfArray(uclx);
        if (getMinOfArray(avgXBar) < min_data){
          min_data = getMinOfArray(avgXBar);
        }
        if(getMaxOfArray(avgXBar) > max_data){
          max_data = getMaxOfArray(avgXBar);
        }
        controlChartYMin = min_data - controlChartData.yInterval;
        /*alert(controlChartYMin)*/
        controlChartXMax = avgXBar.length + 1;
        controlChartYMax = max_data + controlChartData.yInterval;
        if(min_data == max_data){
          controlChartYMin -= 3;
          controlChartYMax +=3;}
        var rangeChartData = controlAndRangeDataSet.rangeChartData;
        uclr = rangeChartData.uclr;
        lclr = rangeChartData.lclr;
        range = rangeChartData.range;
        r_bar = rangeChartData.r_bar;
        rangeChartXLabel = rangeChartData.xLabel;
        rangeChartYLabel = rangeChartData.yLabel;
        rangeChartXMin = 1;
        var min_data1 = getMinOfArray(lclr);
        var max_data1 = getMaxOfArray(uclr);
        if(getMinOfArray(range) < min_data1){
          min_data1 = getMinOfArray(range);
        }
        if(getMaxOfArray(range) > max_data1){
          max_data1 = getMaxOfArray(range);
        }

        rangeChartYMin = min_data1 - rangeChartData.yInterval;
        rangeChartXMax = range.length + 1;
        rangeChartYMax = max_data1 + rangeChartData.yInterval;
        if(min_data1 == max_data1){
          rangeChartYMin -= 3;
          rangeChartYMax +=3;}
        // Plot Chart Start
        var plot1 = $.jqplot(control_div_id, [uclx, avgXBar, lclx], {
            title: 'X Bar Chart',
            axesDefaults: {
                tickOptions: {
                        showGridline: false,
                },
                labelRenderer: $.jqplot.CanvasAxisLabelRenderer
            },
            highlighter: {
                show: true,
                tooltipAxes: 'y',
                formatString: "%#.4f"
            },
            series: [{
                label: 'UCLx - ' + getFourDecimalPoints(uclx[0]).toString(),
                color: 'red',
            }, {
                label: 'X bar',
                color: 'blue',
                showMarker: true,
                markerOptions: {
                    style: 'diamond'
                }
            }, {
                label: 'LCLx - ' + getFourDecimalPoints(lclx[0]).toString(),
                color: 'red'
            }],
            legend: {
                renderer: $.jqplot.EnhancedLegendRenderer,
                show: true,
                location: 'ne',
                placement: 'inside',
                fontSize: '10px',
                dataLabels: 'label',
                background: 'white',
                textColor: 'black',
            },
            seriesDefaults: {
                rendererOptions: {
                    //smooth: true,
                    animation: {
                        show: true,
                    },
                },
                showMarker: false,
            },
            axes: {
                xaxis: {
                    label: controlChartXLabel,
                    min: controlChartXMin,
                    max : controlChartXMax,
                    tickInterval: 1,
                },
                yaxis: {
                    label: controlChartYLabel,
                    min: controlChartYMin,
                    max : controlChartYMax,
                    tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                    tickOptions:{
                      formatString: "%#.4f"
                    },
                },
            },
            cursor: {
                show: true,
                zoom: true,
            },
            grid: {
                backgroundColor: '#FFFFFF'
            }
        });

        var plot2 = $.jqplot(range_div_id, [uclr, range, lclr], {
            title: 'Range Chart',
            axesDefaults: {
                tickOptions: {
                    showGridline: false,
                },
                labelRenderer: $.jqplot.CanvasAxisLabelRenderer
            },
            highlighter: {
                show: true,
                tooltipAxes: 'y',
                formatString: "%#.4f"
            },
            series: [{

                label: 'UCLr - ' + getFourDecimalPoints(uclr[0]).toString(),
                color: 'red',
            }, {
                label: 'Range (R)',
                color: 'blue',
                showMarker: true,
                markerOptions: {
                    style: 'diamond'
                }
            }, {
                label: 'LCLr - ' + getFourDecimalPoints(lclr[0]).toString(),
                color: 'red'
            }],
            legend:{
              renderer: $.jqplot.EnhancedLegendRenderer,
              show: true,
              location: 'ne',
              placement: 'inside',
              fontSize: '10px',
              dataLabels: 'label',
              background: 'white',
              textColor: 'black',
            },
            seriesDefaults: {
                rendererOptions: {
                    animation: {
                        show: true,
                    }
                },
                showMarker: false,
            },
            axes: {
                xaxis: {
                    label: rangeChartXLabel,
                    min: rangeChartXMin,
                    tickInterval: 1,
                },
                yaxis: {
                    label: rangeChartYLabel,
                    min: rangeChartYMin,
                    max: rangeChartYMax,
                    tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                    tickOptions:{
                      formatString: "%#.4f"
                    },
                },
            },
            cursor: {
                show: true,
                zoom: true
            },
            grid: {
                backgroundColor: '#FFFFFF'
            }
        });
        // Plot Chart End
    }
    catch (error) {
        console.log(error.message);
        if (error.message == "No data specified") {
            alert("No data retrived for selected options.");
        }
    }
}

function plotPpmChart(ppmResultDataSet, screen = ""){
  if(screen == "asn")
  {
    output_div = 'ppm_chart'
  }
  else{
    output_div = 'chart1'
  }
  console.log(ppmResultDataSet);
try{
  var prevTwoYearData = ppmResultDataSet.prevTwoYearData;
  var monthsData = ppmResultDataSet.monthsData;

  var selectedYearData = ppmResultDataSet.selectedYearData;

  var barWidthAndPadding = 35;
  var totalNoOfMonths =monthsData.length;
  if(totalNoOfMonths > 10){
    barWidthAndPadding = 25;
  }else if (totalNoOfMonths > 8) {
    barWidthAndPadding = 30;
  }else {
    barWidthAndPadding = 40;
  }

  var plot2 = $.jqplot(output_div, [prevTwoYearData,monthsData,selectedYearData], {
      title: 'PPM Report',
      stackSeries: false,
      axesDefaults: {
          tickOptions: {
              showGridline: true
          },
          labelRenderer: $.jqplot.CanvasAxisLabelRenderer
      },
      seriesDefaults: {
        rendererOptions: {
            highlightMouseOver: false,
        },
        breakOnNull:true,
      },
      animate: !$.jqplot.use_excanvas,
      highlighter: {

          show: false,
          tooltipAxes: 'y',
          formatString: "%#.4f"

      },
      series: [
              //bar chart for prev Two Year Prpo
              {
                disableStack : true,
                renderer:$.jqplot.BarRenderer,
                color:'#2881FC',
                pointLabels: {
                    renderer : $.jqplot.DefaultTickFormatter,
                    show: true,
                    stackedValue: true,
                    formatString: "%#.2f"
                },
                rendererOptions: {
                   barPadding : -barWidthAndPadding,
                   //barMargin : 0,
                   barDirection : 'vertical',
                   barWidth : barWidthAndPadding,
                },
              },
              //Line chart for Actual Month Data
              {
                  disableStack : true,//otherwise it wil be added to values of previous series
                  renderer: $.jqplot.LineRenderer,
                  //lineWidth: 2,
                  color:'red',
                  pointLabels: {
                    show: true
                  },
                  markerOptions: {
                      size: 5
                  }
              },
              //Line chart for Empty Month Data
              {
                disableStack : true,
                renderer:$.jqplot.BarRenderer,
                showMarker:false,
                color: '#FC28EB',
                pointLabels: {
                    show: true,
                    stackedValue: true
                },
                rendererOptions: {
                   barPadding : -barWidthAndPadding,
                   //barMargin : 0,
                   barDirection : 'vertical',
                   barWidth : barWidthAndPadding,
                },
              },
          ],
          cursor:{
              show: true,
              zoom: true
          },
          axes: {
              xaxis: {
                  renderer: $.jqplot.CategoryAxisRenderer,
                  min:0,
                  pad: 1.05,
                  tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
                  tickOptions: {
                     fontSize: '10pt',
                     angle: -90,
                     labelPosition: 'middle',
                  },
              },
              yaxis: {
                  tickRenderer: $.jqplot.CanvasAxisTickRenderer,
                  autoscale: false,
                  min:0,
                  //tickInterval: 1,
                  tickOptions:{
                    formatString: "%#.4f"
                  },
              }
          }
  });
  }
    catch(error){
      console.log(error.message);
      if(error.message=="No data specified"){
        alert("No data retrived for selected options.");
      }
    }
}


function plotCpCpkChart(cpcpkChartDataSet, screen = " "){

   if(screen == "asn")
   {
      output_div = 'cp_cpk_chart'

    }
    else{

      output_div = 'chart1'
    }

  try{

    ticks = cpcpkChartDataSet.ticks;
    cpValues = cpcpkChartDataSet.cp;
    cpkValues = cpcpkChartDataSet.cpk;

    var grid = {
        gridLineWidth: 1.5,
        gridLineColor: 'rgb(235,235,235)',
        drawGridlines: true
    };

    var max_data = 1.4000 ;


    if(getMaxOfArray(cpValues) > max_data){
      max_data = getMaxOfArray(cpValues);
    }
    if(getMaxOfArray(cpkValues) > max_data){
      max_data = getMaxOfArray(cpValues);
    }

    chartYMax = max_data;

    // Plot Chart Start
    console.log("Plotting CP/CPK...");
    console.log(cpValues);
    console.log(cpkValues);


    var plot1 = $.jqplot (output_div, [cpValues,cpkValues],{
        title: 'Cp/Cpk Chart',
        axesDefaults: {
            tickOptions: {
                showGridline: true
            },
            labelRenderer: $.jqplot.CanvasAxisLabelRenderer
        },
        highlighter: {
            show:true,
            tooltipAxes: 'y',
        },
        series:[
          {
            renderer:$.jqplot.LineRenderer,
            label:'Cp',
            color: 'red',
            showMarker:true,
            markerOptions: {
              style:'filledSquare'
            },
            highlighter: {
                show: true,
            },
            pointLabels: {
                  show: true,
                  location:'s',
                  formatString: "%#.4f"
            },
          },
          {
            renderer:$.jqplot.LineRenderer,
            label:'Cpk',
            color: 'blue',
            showMarker:true,
            markerOptions: {
              style:'filledDiamond'
            },
            pointLabels: {
                  show: true,
                  location:'n',
                  formatString: "%#.4f"
            },
            highlighter: {
                show: true,
            },
          },
        ],
        legend:{
          show:true,
          location:'ne',
          placement:'inside',
          fontSize:'8px',
          dataLabels: 'label',
          formatString: "%#.4f",
          rendererOptions: {
              numberRows: 1
          },
        },
        seriesDefaults: {
          rendererOptions: {
            smooth: true,
            animation: {
              show:true,
            }
          },
          showMarker:false,
          breakOnNull:true,
        },
        axes:{
          xaxis:{
            renderer: $.jqplot.CategoryAxisRenderer,
            tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
            tickOptions: {
               fontSize: '10pt',
               angle: -90,
               labelPosition: 'middle',
               showGridline: true,
            },
            ticks: ticks
          },
          yaxis:{
            label:"values",
            max:chartYMax,
            tickRenderer: $.jqplot.CanvasAxisTickRenderer,
            tickOptions:{
              showGridline: true,
              formatString: "%#.4f"
            }
          },
        },
        grid: grid,
        canvasOverlay: {
            show: true,
            objects: [
                {dashedHorizontalLine: {
                    name: 'boundary',
                    y: 1.3300,
                    lineWidth: 1,
                    color: 'rgb(0, 0, 255)',
                    shadow: false,
                    showTooltip: true,
                    tooltipFormatString: 'Cpk Target min 1.33'
                }}
            ]
        },
        cursor: {
            show: true,
            zoom: true,
        }
      });
    console.log("CP/CPK Plotted.");
    }
    catch(error){
      console.log(error.message);
      if(error.message=="No data specified"){

      }
    }
}


function histogram(ppmResultDataSetForProcess, output_div){
try{
    console.log("Plotting histogram...");
    var plotData = ppmResultDataSetForProcess.values;
    var color_list = ppmResultDataSetForProcess.series_color;
    $.each(plotData, function (index, value) {
      value[0] +='';
    });

    var plot2 = $.jqplot(output_div, [plotData], {
        title:'Histogram',
        seriesColors:color_list,
        seriesDefaults: {
          pointLabels: {
              show: true,
              stackedValue: true
          },
          rendererOptions:{
            barWidth:10,
            varyBarColor:true
          }
        },
        animate: !$.jqplot.use_excanvas,
        series: [
                {
                    shadow: false,
                    renderer: $.jqplot.BarRenderer,
                    color:'blue',
                    rendererOptions: {
                        barMargin: 0,
                    }
                }
        ],
        axesDefaults: {
            tickOptions: {
                show:true,
                showGridline: false
            },
            labelRenderer: $.jqplot.CanvasAxisLabelRenderer
        },
        axes: {
            xaxis: {
              renderer: $.jqplot.CategoryAxisRenderer,
              tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
                tickOptions: {
                  angle: -90,
                  fontSize: '10pt',
                  formatString: "%#.4f"
                }
            },
            yaxis: {
              min:0,
            }
        },
        cursor: {
            show: true,
            zoom: true,
        },
        grid: {
            show:false,
            backgroundColor: '#FFFFFF'
        }
    });
    console.log("Histogram plotted...");
  }
  catch(error){
    console.log(error.message);
    if(error.message == "No data specified"){
      alert("No data retrived for selected options.");
    }
  }
}

function plotPpmDailyChart(ppmResultDataSet){
  console.log(ppmResultDataSet);
try{
  var dailyData = ppmResultDataSet.dailyData;

  console.log("Plotting PPM Daily Chart...");
  var plot2 = $.jqplot('chart1', [dailyData], {
      title:'PPM Daily Chart',
      seriesDefaults: {
        breakOnNull:true,
      },
      axes:{
        xaxis:{
          renderer:$.jqplot.DateAxisRenderer,
          tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
          tickOptions:{
            formatString:'%b %#d',
            showGridline: false,
            angle: -90,
          },
          tickInterval:'1 day'
        },
        yaxis:{
          tickRenderer: $.jqplot.CanvasAxisTickRenderer,
          tickOptions:{
            showGridline: false,
            formatString: "%#.4f"
          },
        }
      },
      highlighter: {
          show: true,
      },
      legend:{
        show:true,
        location:'ne',
        placement:'inside',
        fontSize:'8px',
        labels: ["PPM"],
        rendererOptions: {
            numberRows: 1
        },
      },
      series:[
        {
          lineWidth:4,
          markerOptions:{
          style:'square'
          },
          pointLabels: { show:true, formatString: "%#.2f" }
        }

      ],
      cursor: {
          show: true,
          zoom: true,
      },
      grid: {
          backgroundColor: '#FFFFFF'
      }
  });
  console.log("Chart plotted.");
}
catch(error){
  console.log(error.message);
  if(error.message == "No data specified"){
    alert("No data retrived for selected options.");
  }
}
}


function get_X_margin(x_values){
  max = Math.max(x_values)
  min = Math.min(x_values)
  x_range = (max - min)/5
  return x_range
}

function get_Y_margin(x_values){
  max = Math.max(y_values)
  min = Math.min(y_values)
  y_range = (max - min)/5
  return y_range
}

function calculate_avg_y_histogram(dataList){
  var total = 0;
  length = 0;
  $.each(dataList,function(index, value) {
      total += value[1];
      length = index;
  });
  console.log("calculate_avg_x_histogram: "+ total / length);
  return total / length;
}

function get_min_y_histogram(dataList){
  min = '';
  $.each(dataList,function(index, value) {
    if(min==''){
        min = value[1];
    }
    else if(min > value[1]){
      min = value[1];
    }
    console.log("get_min_x_histogram: "+ min);
    return min;
  });
}

function calculate_avg_x_histogram(dataList){
  var total = 0;
  length = 0;
  $.each(dataList,function(index, value) {
      total += value[0];
      length = index;
  });
  console.log("calculate_avg_x_histogram: "+ total / length);
  return total / length;
}

function get_min_x_histogram(dataList){
  min = '';
  $.each(dataList,function(index, value) {
    if(min==''){
        min = value[0];
    }
    else if(min > value[0]){
      min = value[0];
    }
    console.log("get_min_x_histogram: "+ min);
    return min;
  });
}
