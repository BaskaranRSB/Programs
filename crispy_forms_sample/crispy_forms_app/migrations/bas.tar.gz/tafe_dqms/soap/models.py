import base64

from django.db import models
from django.core.exceptions import ValidationError

from inspection.models import Batch


class Config(models.Model):
    """ Configuration model for SOAP post """
    username = models.CharField(
        max_length=60)
    password = models.CharField(
        max_length=60)
    url = models.CharField(
        max_length=250,
        help_text=('''Please provide the soap URL.\t
                   	Example: \"http://192.168.1.203:9080/meaweb/services/TBLWORKORDER\"'''))
    soap_action = models.CharField(
        max_length=250,
        help_text="Please provide SOAPACTION. Example: \"urn:processDocument\"")

    def save(self, *args, **kwargs):
        self.password = base64.b64encode(self.password)
        super(Config, self).save(*args, **kwargs)

    def clean(self):
        model = self.__class__
        if (model.objects.count() > 0 and
                self.id != model.objects.get().id):
            raise ValidationError(
                "Can only create 1 %s instance" % model.__name__)

    def __str__(self):
        return self.url

    class Meta:
        db_table = "Config"


class PostedBatchDate(models.Model):
    """model for storing posted batch date"""

    posted_batch = models.ForeignKey(
        Batch, on_delete=models.CASCADE, unique=True)
    date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.id
