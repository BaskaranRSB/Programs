from django.contrib import admin
from django.forms import ModelForm, PasswordInput

from .models import Config


class SOAPForm(ModelForm):

    class Meta:
        model = Config
        fields = "__all__"
        widgets = {
            'password': PasswordInput(),
        }


class SOAPAdmin(admin.ModelAdmin):
    form = SOAPForm


admin.site.register(Config, SOAPAdmin)
