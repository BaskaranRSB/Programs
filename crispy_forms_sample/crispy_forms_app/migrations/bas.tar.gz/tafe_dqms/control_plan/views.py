import os
import zipfile
import StringIO
import json
import logging

from django.shortcuts import render, render_to_response
from django.views.generic import View
from django.http import JsonResponse, HttpResponse
from django.template.response import TemplateResponse
from django.core import serializers
from django.core.exceptions import ValidationError
from wsgiref.util import FileWrapper

from .forms import UploadForm, get_supplier_list, get_part_list
from .models import ControlPlan, Supplier, Part, PartSupplier
from .parser import Parser
from login.views import LoginRequiredMixin

logger = logging.getLogger(__name__)


class ControlPlanView(LoginRequiredMixin, View):
    template_name = "control_plan/control_plan.html"

    def get(self, request):
        if 'cp_id' in request.GET:
            return self.zipfiles(request)
        part = get_part_list()
        supplier = get_supplier_list()
        table_data = ControlPlan.objects.filter(is_active=True)
        up_form = UploadForm()
        return render(request, self.template_name, {
            'table_data': table_data,
            'up_form': up_form,
            'supplier_list': supplier,
            'part_list': part,
        })

    def post(self, request):
        supplier_list, part_list = self.get_list(request)
        table_data = self.get_table_data(supplier_list, part_list)
        response = self.render_table_data(request, table_data)
        return JsonResponse(response, safe=False)

    def render_table_data(self, request, table_data):
        template = TemplateResponse(request, 'table.html', {
            'table_data': table_data,
        })
        template.render()
        return template.content

    def get_table_data(self, supplier_list, part_list):
        if len(part_list) != 0 and len(supplier_list) != 0:
            return ControlPlan.objects.filter(
                supplier__vendor_code__in=supplier_list,
                is_active=True
            ).filter(part__pk__in=part_list)
        elif len(part_list) != 0:
            return ControlPlan.objects.filter(
                part__pk__in=part_list,
                is_active=True)
        elif len(supplier_list) != 0:
            return ControlPlan.objects.filter(
                supplier__vendor_code__in=supplier_list,
                is_active=True)
        else:
            return ControlPlan.objects.filter(
                is_active=True)

    def get_list(self, request):
        supplier_list = []
        part_list = []
        if 'supplierlist' in request.POST:
            supplier_list = request.POST.getlist('supplierlist')
        if 'partlist' in request.POST:
            part_list = request.POST.getlist('partlist')
        return (supplier_list, part_list)

    def get_list_files(self, request):
        cp_id = request.GET.get('cp_id')
        control_plan = ControlPlan.objects.get(
            id=cp_id)
        if control_plan.pdi_file and control_plan.cp_file:
            return [str(control_plan.cp_file.path),
                    str(control_plan.pdi_file.path)]
        elif control_plan.pdi_file:
            return [str(control_plan.pdi_file.path)]
        elif control_plan.cp_file:
            return [str(control_plan.cp_file.path)]

    def zipfiles(self, request):
        try:
            # Files (local path) to put in the .zip
            # FIXME: Change this (get paths from DB etc)
            filenames = self.get_list_files(request)

            # Folder name in ZIP archive which contains the above files
            # E.g [thearchive.zip]/somefiles/file2.txt
            # FIXME: Set this to something better
            zip_subdir = "files"
            zip_filename = "%s.zip" % zip_subdir

            # Open StringIO to grab in-memory ZIP contents
            s = StringIO.StringIO()

            # The zip compressor
            zf = zipfile.ZipFile(s, "w")

            for fpath in filenames:
                # Calculate path for file in zip
                fdir, fname = os.path.split(fpath)
                zip_path = os.path.join(zip_subdir, fname)

                # Add file, at correct path
                zf.write(fpath, zip_path)

            # Must close zip for all contents to be written
            zf.close()

            # Grab ZIP file from in-memory, make response with correct
            # MIME-type
            response = HttpResponse(s.getvalue(),
                                    content_type="application/zip")
            # ..and correct content-disposition
            response[
                'Content-Disposition'] = 'attachment; filename=%s' % zip_filename
            return response
        except OSError:
            return render_to_response(
                'control_plan/control_plan.html', {
                    "message": 'Files Does Not Exist.'
                })


def get_supplier(request):
    data = {}
    data_list = {}
    data_list_item = []
    has_part_id_list = request.GET.has_key('part_id_list')
    if has_part_id_list:
        part_id_list = request.GET['part_id_list'].split(",")
        supplier_list = [supplier
                         for part in part_id_list
                         for supplier in get_supplier_list(part)]
    else:
        supplier_list = get_supplier_list()
    for supplier in supplier_list:
        list_of_supplier = {
            "id": str(supplier.vendor_code), "name": supplier.vendor_name}
        data_list_item.append(list_of_supplier)
    data_list_unique = {each['id']: each for each in data_list_item}.values()
    data_list['data'] = data_list_unique
    return JsonResponse(data_list, safe=True)


class UploadView(LoginRequiredMixin, View):

    def get(self, request, *args, **kwargs):
        active_suppliers = [
            int(supplier['supplier'])
            for supplier in PartSupplier.objects.filter(
                part=request.GET['part_no'],
                is_active=True).values('supplier')]
        data = serializers.serialize(
            'json', Supplier.objects.filter(
                id__in=active_suppliers),
            fields=('id', 'vendor_code', 'vendor_name',)
        )
        response = json.loads(data)
        return JsonResponse(response, safe=False)

    def post(self, request, *args, **kwargs):
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                parser = Parser(
                    part=request.POST.get('part_no'),
                    supplier_list=request.POST.getlist('supplier_id'),
                    cp_plan=request.FILES.get('control_plan', None),
                    pdi_plan=request.FILES.get('pdi_plan', None)
                )
                response = {
                    "status": 1,
                    "message": parser.save()
                }
                return JsonResponse(response, safe=True)
            except ValidationError as error:
                response = {
                    "status": 0,
                    "message": error.params
                }
                return JsonResponse(response, safe=True)
        response = {
            "status": 0,
            "message": form.errors
        }
        return JsonResponse(response, safe=False)
