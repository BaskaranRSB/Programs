from django.conf.urls import url
from .views import ControlPlanView, get_supplier, UploadView

urlpatterns = [
    url(r'^plan/', ControlPlanView.as_view(), name='plan'),
    url(r'plan/(?P<cp_id>[0-9]+)$',
        ControlPlanView.as_view(), name='download'),
    url(r'plan/(?P<id>[0-9]+)$',
        ControlPlanView.as_view(), name='selected_upload'),
    url(r'^plan/', ControlPlanView.as_view(), name='plan'),
    url(r'^get_supplier/', get_supplier, name='get_part'),
    url(r'^upload/$', UploadView.as_view(), name='upload'),
    url(r'^(?P<part_no>[0-9]+)$',
        UploadView.as_view(), name='filter_part_id'),
]
