import os
from decimal import InvalidOperation

from django.test import TestCase
from django.db import IntegrityError
from django.core.exceptions import ObjectDoesNotExist
from django.core.files import File as DjangoFile

from .models import ControlPlan, Part, Supplier
from .forms import ControlPlanForm, ProcessForm, CharacteristicsForm

# Create your tests here.


class ControlPlanTestCase(TestCase):

    def setUp(self):
        Part.objects.create(name="Part1")
        Supplier.objects.create(name="Supplier1")

    def test_save_with_out_part_instance(self):
        self.assertRaisesMessage(
            ObjectDoesNotExist,
            'Control_Plan has no part.',
            ControlPlan.objects.create
        )

    def test_save_non_nullable_field_inprocess_version(self):
        part = Part.objects.get(name="Part1")
        self.assertRaisesMessage(
            IntegrityError,
            'NOT NULL constraint failed: ControlPlan.inprocess_version',
            ControlPlan.objects.create,
            part=part
        )

    def test_save_non_nullable_field_PDI_version(self):
        part = Part.objects.get(name="Part1")
        self.assertRaisesMessage(
            IntegrityError,
            'NOT NULL constraint failed: ControlPlan.PDI_version',
            ControlPlan.objects.create,
            part=part,
            inprocess_version=1.1
        )

    def test_save_invalid_inprocess_version(self):
        part = Part.objects.get(name="Part1")
        self.assertRaisesMessage(
            InvalidOperation,
            'quantize result has too many digits for current context',
            ControlPlan.objects.create,
            part=part,
            inprocess_version=111.00,
            PDI_version=1.00
        )

    def test_save_invalid_PDI_version(self):
        part = Part.objects.get(name="Part1")
        self.assertRaisesMessage(
            InvalidOperation,
            'quantize result has too many digits for current context',
            ControlPlan.objects.create,
            part=part,
            inprocess_version=1.00,
            PDI_version=111.00
        )

    def test_unique_together(self):
        part = Part.objects.get(name="Part1")
        supplier = Supplier.objects.get(name="Supplier1")
        ControlPlan.objects.create(
            part=part,
            supplier=supplier,
            inprocess_version=1.00,
            PDI_version=1.00
        )
        self.assertRaisesMessage(
            IntegrityError,
            'UNIQUE constraint failed: ControlPlan.part_id,' +
            ' ControlPlan.inprocess_version, ControlPlan.PDI_version',
            ControlPlan.objects.create,
            part=part,
            inprocess_version=1.00,
            PDI_version=1.00
        )


class ControlPlanFormTest(TestCase):

    def setUp(self):
        self.BASE_DIR = os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))
        )
        self.s1 = Supplier.objects.create(name="Supplier1")
        self.s2 = Supplier.objects.create(name="Supplier2")
        self.s3 = Supplier.objects.create(name="Supplier3")
        self.p1 = Part.objects.create(name="Part1")
        self.p1.supplier.add(self.s1, self.s2)

    def test_validation(self):
        form_data = {
            'part': Part.objects.get(name="Part1"),
            'supplier': self.s3,
            'inprocess_version': 1.1,
            'PDI_version': 1.1,
            'created_on': '2006-10-25',
        }
        form = ControlPlanForm(data=form_data)
        print form.errors['prepared_by']
        self.assertFalse(form.is_valid())
