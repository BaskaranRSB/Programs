from __future__ import unicode_literals

from django.db import models
from django.core.validators import MaxValueValidator
# Create your models here.


class Vendor_Staging(models.Model):
    vendor_code = models.CharField(max_length=60)
    vendor_name = models.CharField(max_length=60)
    part_id = models.CharField(max_length=60)
    part_desc = models.CharField(max_length=500)

    class Meta:
        db_table = 'vendor_staging'

