import time
import logging

from .models import Vendor_Staging
from control_plan.models import Part, Supplier, PartSupplier
from inspection.models import Batch, InspectionSamples

logger = logging.getLogger(__name__)


def refresh_masterdata(_time):
    while True:
        deactivate_part_supplier()
        for staging_data in Vendor_Staging.objects.all():
            is_supplier_modified, supplier = save_supplier(staging_data)
            is_part_modified, part = save_part(staging_data)
            if is_supplier_modified or is_part_modified:
                save_part_supplier(supplier.id, part.id)
                logger.info('Master table data refreshed.')
        time.sleep(_time)


def deactivate_part_supplier():
    PartSupplier.objects.all()
    supplier_list = Vendor_Staging.objects.all().values_list(
        "vendor_code", flat=True)
    part_list = Vendor_Staging.objects.all().values_list(
        "part_id", flat=True)
    deactivate_partsupplier_list = PartSupplier.objects.exclude(
        part__tafe_part_id__in=part_list,
        supplier__vendor_code__in=supplier_list
    )
    for part_supplier in deactivate_partsupplier_list:
        if part_supplier.is_active is not False:
            part_supplier.is_active = False
            part_supplier.save()
    activate_partsupplier_list = PartSupplier.objects.exclude(
        id__in=deactivate_partsupplier_list.values_list("id", flat=True)
    )
    for part_supplier in activate_partsupplier_list:
        if part_supplier.is_active is not True:
            part_supplier.is_active = True
            part_supplier.save()


def save_part_supplier(supplier_id, part_id):
    try:
        part = Part.objects.get(id=part_id)
        supplier = Supplier.objects.get(id=supplier_id)
        part_supplier = PartSupplier.objects.get(
            part=part_id,
            supplier=supplier_id)
        part_supplier.is_active = True
        part_supplier.save()
    except PartSupplier.DoesNotExist:
        PartSupplier.objects.create(
            part=part,
            supplier=supplier,
            is_active=True)


def save_part(staging_data):
    is_part_modified = False
    try:
        part = Part.objects.get(
            tafe_part_id=staging_data.part_id,
        )
        if (part.description != staging_data.part_desc or
                part.name != staging_data.part_desc):
            part.description = staging_data.part_desc
            part.name = staging_data.part_desc
            part.save()
            is_part_modified = True
    except Part.DoesNotExist:
        part = Part.objects.create(
            name=staging_data.part_desc,
            tafe_part_id=staging_data.part_id,
            description=staging_data.part_desc
        )
        is_part_modified = True
    return is_part_modified, part


def save_supplier(staging_data):
    is_supplier_modified = False
    try:
        supplier = Supplier.objects.get(
            vendor_code=staging_data.vendor_code)
        if(supplier.vendor_name != staging_data.vendor_name):
            supplier.vendor_name = staging_data.vendor_name
            supplier.save()
            is_supplier_modified = True
    except Supplier.DoesNotExist:
        supplier = Supplier.objects.create(
            vendor_code=staging_data.vendor_code,
            vendor_name=staging_data.vendor_name)
        is_supplier_modified = True
    return is_supplier_modified, supplier
