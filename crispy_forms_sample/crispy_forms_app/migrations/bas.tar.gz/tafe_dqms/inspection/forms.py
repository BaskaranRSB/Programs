import operator

from django import forms
from django.utils.translation import ugettext_lazy as _
from django.forms import ModelMultipleChoiceField, ModelChoiceField

from multiupload.fields import MultiFileField

from control_plan.models import Part, Supplier, Characteristics, Process, PartSupplier, ControlPlan
from control_plan.forms import get_supplier_list, get_part_list
from .models import Batch, EndedBatchReport, InspectionSamples, InspectionCharacteristics

from tafe_dqms.custom_form_fields import GroupedModelChoiceField, GroupedModelMultiChoiceField


class SupplierIdMultiChoiceField(ModelMultipleChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.vendor_code)
class SupplierNameMultiChoiceField(ModelMultipleChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.vendor_name)

class PartIdMultiChoiceField(ModelMultipleChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.tafe_part_id)
class PartNameMultiChoiceField(ModelMultipleChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.name)


class SupplierIdChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.vendor_code)


class SupplierNameChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.vendor_name)


class SupplierChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s-%s" % (obj.vendor_code, obj.vendor_name)


class PartIdChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.tafe_part_id)


class PartNameChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s" % (obj.name)


class PartChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s-%s" % (obj.tafe_part_id, obj.name)


class ControlPlanChoiceField(ModelChoiceField):

    def label_from_instance(self, inprocess_version):
        return "Version -%s" % (inprocess_version)


class OperationChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s-%s" % (obj.process_id, obj.name)


class CharacteristicsChoiceField(ModelMultipleChoiceField):

    def label_from_instance(self, obj):
        return "%s(%s)" % (obj.product, obj.product_spec)


class BatchChoiceField(forms.MultipleChoiceField):

    def label_from_instance(self, obj):
        return "%s" % obj.id


def get_process_choices(part, supplier, control_plan_version):
    return (
        (value["id"], "{process_number}-{name}".format(
            name=value["name"],
            process_number=value["process_id"]))
        for value in Process.objects.filter(
            control_plan__part=part,
            control_plan__supplier=supplier,
            control_plan__inprocess_version=control_plan_version
        ).order_by('process_order').values(
            'id', 'name', 'process_id')
    )


def get_batch_field(initial):
    batch_list = []
    if initial["from_date"] and initial["to_date"]:
        batch_list = Batch.objects.filter(
            process__id=initial["operations"],
            batch_start_date__gt=initial["from_date"],
            batch_start_date__lt=initial["to_date"]
        )
    elif not initial["from_date"] and initial["to_date"]:
        batch_list = Batch.objects.filter(
            process__id=initial["operations"],
            batch_start_date__lte=initial["to_date"]
        )
    elif initial["from_date"] and not initial["to_date"]:
        batch_list = Batch.objects.filter(
            process__id=initial["operations"],
            batch_start_date__gte=initial["from_date"]
        )
    elif not initial["from_date"] and not initial["to_date"]:
        batch_list = Batch.objects.filter(
            process__id=initial["operations"])
    if batch_list:
        return (
            (value["id"], _(value["id"]))
            for value in batch_list.values(
                'id', 'id')
        )
    else:
        return batch_list


def get_characteristics_choices(process, supplier):
    return (
        (value["id"], _(value["product"]))
        for value in Characteristics.objects.filter(
            process=process,
            process__control_plan__supplier=supplier
        ).values(
            'id', 'product')
    )


def get_control_plan_choices(part, supplier):
    control_plan_list = ControlPlan.objects.filter(
        part=part,
        supplier=supplier
    ).values_list(
        'inprocess_version', flat=True)
    return control_plan_list

SHOW_CHOICES = (
    ('Qualified', _("Qualified")),
    ('Rejected', _("Rejected")),
    ('Reworked', _("Reworked")),
    ('Remeasured', _("Remeasured"))
)


class FilterForm(forms.Form):
    part = PartChoiceField(
        queryset=get_part_list(),
        empty_label="Select Part"
    )
    supplier = SupplierChoiceField(
        queryset=Supplier.objects.none(),
        empty_label="Select Supplier"
    )
    control_plan = ControlPlanChoiceField(
        queryset=ControlPlan.objects.none(),
        empty_label="Select Control Plan"
    )
    operations = forms.ChoiceField(
        choices=(),
        widget=forms.Select,
        required=False
    )
    from_date = forms.DateField()
    to_date = forms.DateField()
    batch = forms.MultipleChoiceField(
        widget=forms.SelectMultiple,
        choices=(),
    )
    characteristics = forms.MultipleChoiceField(
        widget=forms.SelectMultiple,
        choices=(),
    )
    show = forms.ChoiceField(
        choices=SHOW_CHOICES,
        widget=forms.SelectMultiple,
        required=False
    )

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        initial = kwargs.get('initial', {})
        super(FilterForm, self).__init__(*args)
        self.fields['part'].widget.attrs = {
            'id': 'id_part', 'class': 'form-control PartClass'}
        self.fields['supplier'].widget.attrs = {
            'id': 'id_supplier', 'class': 'form-control SupplierClass', 'name' : 'supplier'}
        self.fields['control_plan'].widget.attrs = {
            'id': 'id_control_plan', 'class': 'form-control ControlPlanClass'}
        self.fields['operations'].widget.attrs = {
            'id': 'id_operations', 'class': 'form-control OperationClass'}
        self.fields['characteristics'].widget.attrs = {
            'id': 'id_characteristics',
            'class': 'form-control CharacteristicsClass'}
        self.fields['batch'].widget.attrs = {
            'id': 'id_batch',
            'class': 'form-control BatchClass',
            'style': 'width:434px'}
        self.fields['from_date'].widget = forms.DateTimeInput(
            attrs={'class': 'form-control', 'style': 'width:200px'})
        self.fields['to_date'].widget = forms.DateTimeInput(
            attrs={'class': 'form-control', 'style': 'width:200px'})
        self.form_initialize(user, initial)

    def form_initialize(self, user, initial):
        map(self.disable_field, ['supplier', 'operations', 'characteristics', 'batch',
                                 'control_plan', 'show', 'from_date', 'to_date'])
        if user["role"] != "Vendor":
            self.initiate_form_tafe(initial)
        else:
            self.initiate_form_supplier(user, initial)
        self.set_initial_value(user, initial)

    def initiate_form_tafe(self, initial):
        try:
            self.fields['supplier'].queryset = get_supplier_list(initial[
                'part'])
            self.enable_field('supplier')
            self.fields['control_plan'].queryset = get_control_plan_choices(
                initial["part"], initial["supplier"])
            self.enable_field('control_plan')
            process = Process.objects.filter(
                control_plan__supplier=initial["supplier"],
                control_plan__part=initial["part"],
                control_plan__is_active=True
            )
            self.fields['operations'].choices = get_process_choices(
                initial["part"], initial["supplier"], initial["control_plan"])
            if len(process) != 0:
                self.enable_field('operations')
            self.fields['characteristics'].choices = get_characteristics_choices(
                initial["operations"], initial["supplier"])
            map(self.enable_field, ['characteristics', 'show',
                                    'from_date', 'to_date'])
            self.fields['batch'].choices = get_batch_field(initial)
            self.enable_field('batch')
        except KeyError:
            pass
        except ValueError:
            pass

    def initiate_form_supplier(self, user, initial):
        try:
            supplier = Supplier.objects.get(
                vendor_code=user['uid']
            )
            self.fields['part'].queryset = get_part_list(supplier.id)
            self.enable_field('control_plan')
            self.fields['supplier'].queryset = Supplier.objects.filter(
                vendor_code=user['uid'])
            self.fields['supplier'].initial = supplier.id
            self.fields['supplier'].disabled = True
            self.fields['control_plan'].queryset = get_control_plan_choices(
                initial["part"], supplier.id)
            self.fields['control_plan'].initial = initial["control_plan"]
            self.enable_field('control_plan')
            self.fields['operations'].choices = get_process_choices(
                initial["part"], supplier.id, initial["control_plan"])
            self.enable_field('operations')
            self.fields['characteristics'].choices = get_characteristics_choices(
                initial["operations"], supplier.id)
            map(self.enable_field, ['characteristics', 'show',
                                    'from_date', 'to_date'])
            self.fields['batch'].choices = get_batch_field(initial)
            self.enable_field('batch')
            self.fields['batch'].initial = initial["batch"]
        except KeyError:
            pass
        except ValueError:
            pass
        except Supplier.DoesNotExist:
            pass

    def set_initial_value(self, user, initial):
        try:
            if user["role"] == 'Vendor':
                for field in ['part', 'operations', 'control_plan', 'from_date', 'to_date', 'characteristics', 'batch'
                              'show']:
                    self.fields[field].initial = initial[field]
            else:
                for field in ['part', 'supplier', 'control_plan', 'operations', 'from_date', 'to_date', 'characteristics', 'batch'
                              'show']:
                    self.fields[field].initial = initial[field]
        except KeyError:
            pass
        except ValueError:
            pass

    def enable_field(self, field_name):
        self.fields[field_name].disabled = False

    def disable_field(self, field_name):
        self.fields[field_name].disabled = True


class EndedBatchReportForm(forms.ModelForm):
    from_date = forms.DateTimeField()
    to_date = forms.DateTimeField()
    attachments = MultiFileField(
        min_num=1, max_num=3, max_file_size=1024 * 1024 * 5)

    def __init__(self, *args, **kwargs):
        initial = kwargs.get('initial', {})
        user = kwargs.get('user', {})
        super(EndedBatchReportForm, self).__init__(*args)
        self.fields['supplier'].empty_label = "Select Supplier"
        self.fields['part'].empty_label = "Select Part"
        self.fields['from_date'].widget = forms.DateTimeInput(
            attrs={'class': 'form-control', 'style': 'width:200px'})
        self.fields['to_date'].widget = forms.DateTimeInput(
            attrs={'class': 'form-control', 'style': 'width:200px'})
        self.fields['ended_batch'].empty_label = "Select Batch"
        self.fields['ended_batch'].widget.attrs = {
            'style': 'width:400px'}
        if not args:
            self.form_initialize(user, initial)

    def get_ended_batch_list(self, initial):
        batch_list = []
        if initial["from_date"] and initial["to_date"]:
            batch_list = Batch.objects.filter(
                process__control_plan__supplier__id=initial['supplier'],
                process__control_plan__part__id=initial['part'],
                batch_start_date__gt=initial["from_date"],
                batch_start_date__lt=initial["to_date"],
                is_batch_ended=True
            )
        elif not initial["from_date"] and initial["to_date"]:
            batch_list = Batch.objects.filter(
                process__control_plan__supplier__id=initial['supplier'],
                process__control_plan__part__id=initial['part'],
                batch_start_date__lte=initial["to_date"],
                is_batch_ended=True
            )
        elif initial["from_date"] and not initial["to_date"]:
            batch_list = Batch.objects.filter(
                process__control_plan__supplier__id=initial['supplier'],
                process__control_plan__part__id=initial['part'],
                batch_start_date__gte=initial["from_date"],
                is_batch_ended=True
            )
        else:
            batch_list = Batch.objects.filter(
                process__control_plan__supplier__id=initial['supplier'],
                process__control_plan__part__id=initial['part'],
                is_batch_ended=True
            )
        return batch_list

    def form_initialize(self, user, initial):
        try:
            map(self.disable_fields, [
                'part', 'ended_batch', 'from_date', 'to_date', 'attachments'])
            if user["role"] == "Vendor":
                self.fields["supplier"].queryset = Supplier.objects.filter(
                    vendor_code=user["uid"])
            else:
                self.fields["supplier"].queryset = Supplier.objects.all()
            self.fields['supplier'].initial = initial['supplier']
            map(self.enable_fields, ['part'])
            map(self.disable_fields, ['ended_batch',
                                      'from_date', 'to_date', 'attachments'])
            part_list = PartSupplier.objects.filter(supplier=initial['supplier']).values_list(
                'part_id', flat=True)
            self.fields['part'].queryset = Part.objects.filter(
                id__in=part_list)
            map(self.enable_fields, ['from_date', 'to_date'])
            self.fields['part'].initial = initial['part']
            map(self.disable_fields, ['ended_batch', 'attachments'])
            self.fields[
                'ended_batch'].queryset = self.get_ended_batch_list(initial)
            map(self.enable_fields, ['ended_batch', 'attachments'])
            self.fields['from_date'].initial = initial['from_date']
            self.fields['to_date'].initial = initial['to_date']
        except KeyError:
            pass
        except ValueError:
            pass

    def save(self, *args, **kwargs):
        for each in self.cleaned_data['attachments']:
            ended_batch = EndedBatchReport.objects.create(
                supplier=self.cleaned_data['supplier'],
                part=self.cleaned_data['part'],
                ended_batch=self.cleaned_data['ended_batch'],
                file=each
            )
        return ended_batch

    def enable_fields(self, field_name):
        self.fields[field_name].disabled = False

    def disable_fields(self, field_name):
        self.fields[field_name].disabled = True

    class Meta:
        model = EndedBatchReport
        fields = ['supplier', 'part',
                  'ended_batch', ]


def get_part_name_list(part_id=None):
    if part_id is not None:
        part_list = Part.objects.filter(
            tafe_part_id=part_id)
    else:
        part_list = Part.objects.all()
    return part_list


def get_supplier_list(part=None):
    if not isinstance(part, list):
        if part is not None:
            supplier_list = PartSupplier.objects.filter(
                part=part, is_active=True).values_list(
                "supplier", flat=True)
        else:
            supplier_list = PartSupplier.objects.filter(
                part=part, is_active=True).values_list(
                "supplier", flat=True)
    else:
        supplier_list = PartSupplier.objects.filter(
            part__in=part, is_active=True).values_list(
            "supplier", flat=True)
    return Supplier.objects.filter(id__in=supplier_list)


class ASNForm(forms.Form):
    invoice = forms.CharField()
    asn = forms.CharField()
    batch = forms.CharField()
    from_date = forms.DateField(input_formats=('%d-%m-%Y'))
    to_date = forms.DateField(input_formats=('%d-%m-%Y'))
    part_id =PartIdMultiChoiceField(
        queryset=Part.objects.all(),
        widget=forms.SelectMultiple(
            attrs={"class": "selectpicker",
                   "data-live-search": "true",
                   'data-width': '200px',
                   "data-actions-box": "true",
                   "data-live-search-placeholder": "Search Part",
                   "data-none-selected-text": "Select Part"})
    )
    part_name =PartNameMultiChoiceField(
        queryset=Part.objects.all(),
        widget=forms.SelectMultiple(
            attrs={"class": "selectpicker",
                   "data-live-search": "true",
                   'data-width': '200px',
                   "data-actions-box": "true",
                   "data-live-search-placeholder": "Search Part",
                   "data-none-selected-text": "Select Part"})
    )
   
   
    supplier_id =SupplierIdMultiChoiceField(
        queryset=Supplier.objects.all(),
        widget=forms.SelectMultiple(
            attrs={"class": "selectpicker",
                   "data-live-search": "true",
                   'data-width': '200px',
                   "data-actions-box": "true",
                   "data-live-search-placeholder": "Search Supplier",
                   "data-none-selected-text": "Select Supplier"})
    )
    
    supplier_name = SupplierNameMultiChoiceField(
        queryset=Supplier.objects.all(),
        widget=forms.SelectMultiple(
            attrs={"class": "selectpicker",
                   "data-live-search": "true",
                   'data-width': '200px',
                   "data-actions-box": "true",
                   "data-live-search-placeholder": "Search Supplier",
                   "data-none-selected-text": "Select Supplier"})
    )

    def __init__(self, *args, **kwargs):
        # user = kwargs.pop('user', None)
        initial = kwargs.get('initial', {})
        super(ASNForm, self).__init__(*args)
        self.fields['invoice'].widget = forms.TextInput(attrs={'placeholder': 'Invoice Number',
                                                               'id': 'invoice', 'class': 'form-control', 'style': 'width:200px'
                                                               })
        self.fields['asn'].widget = forms.TextInput(attrs={'placeholder': 'ASN Number',
                                                           'id': 'asn', 'class': 'form-control', 'style': 'width:200px'
                                                           })
        self.fields['batch'].widget = forms.TextInput(attrs={'placeholder': 'Batch Number',
                                                             'id': 'batch', 'class': 'form-control', 'style': 'width:200px'
                                                             })
        self.fields['from_date'].widget = forms.DateTimeInput(
            attrs={'class': 'form-control', 'style': 'width:200px'})
        self.fields['to_date'].widget = forms.DateTimeInput(
            attrs={'class': 'form-control', 'style': 'width:200px'})
        self.fields['part_id'].widget.attrs = {
            'id': 'part_id', 'class': 'form-control ASNPartClass'}
        self.fields['supplier_id'].widget.attrs = {
            'id': 'supplier_id', 'class': 'form-control ASNSupplierIdClass'}
        self.fields['supplier_name'].widget.attrs = {
            'id': 'supplier_name', 'class': 'form-control ASNSupplierNameClass'}
        self.fields['part_name'].widget.attrs = {
            'id': 'part_name', 'class': 'form-control ASNPartNameClass'}

        #self.override_required_field_error_message()
        self.set_initial_value(initial)

    def set_initial_value(self, initial):
        try:
            # if user["role"] == 'Vendor':
            for field in ['part_id', 'supplier_id', 'supplier_name', 'part_name', 'from_date', 'to_date']:
                self.fields[field].initial = initial[field]
            # else:
            #     for field in ['part_id', 'supplier_id', 'supplier_name', 'part_name', 'from_date', 'to_date']:
            #         self.fields[field].initial = initial[field]
        except KeyError:
            pass
        except ValueError:
            pass

    def is_valid(self, *args, **kwargs):
        try:
            super(UploadForm, self).is_valid(*args, **kwargs)
        except KeyError as e:
            if e.message == "invalid_choice":
                return True

    def override_required_field_error_message(self):
        self.fields["part_id"].error_messages = {
            'required': 'The \'Part No\' is required',
        }
        self.fields["part_name"].error_messages = {
            'required': 'The \'Part Name\' is required',
        }
        self.fields["supplier_name"].error_messages = {
            'required': 'The \'Supplier Name\' is required',
        }
        self.fields["supplier_id"].error_messages = {
            'required': 'The \'Supplier No\' is required',
        }
