from django.contrib import admin

from .models import Batch, SourceBatch, InspectionSamples,\
    InspectionCharacteristics, AsnData, AsnBatch


# Register your models here.
admin.site.register(Batch)
admin.site.register(SourceBatch)
admin.site.register(InspectionSamples)
admin.site.register(InspectionCharacteristics)
admin.site.register(AsnData)
admin.site.register(AsnBatch)
