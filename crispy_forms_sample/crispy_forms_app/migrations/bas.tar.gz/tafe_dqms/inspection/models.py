from __future__ import unicode_literals
import os
import datetime

from django.db import models

from organization.models import Shift, Equipment, Employee
from control_plan.models import Process, StagingServer, Characteristics
from control_plan.models import Supplier, Part, Process, \
    StagingServer, Characteristics
from reports.models import MyManager


def update_filename(instance, filename):
    path = 'batch_reports/'
    format = (str(instance.supplier.vendor_name) + "_"
              + str(instance.part.name) + "_" + str(instance.ended_batch)
              + "_" + datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S")
              + "_" + str(instance.file.name))
    return os.path.join(path, format)


class Batch(models.Model):
    """docstring for Batch"""
    id = models.CharField(max_length=60, primary_key=True,
                          unique=True)  # Should be chaged to 'AutoField'
    stagingserver = models.ForeignKey(
        StagingServer, on_delete=models.CASCADE)
    process = models.ForeignKey(
        Process, on_delete=models.CASCADE)
    shift = models.ForeignKey(
        Shift, on_delete=models.CASCADE)
    equipment = models.ForeignKey(
        Equipment, on_delete=models.CASCADE)
    operator = models.ForeignKey(
        Employee, on_delete=models.CASCADE, related_name='%(class)s_operator')
    inspector = models.ForeignKey(
        Employee, on_delete=models.CASCADE, related_name='%(class)s_inspector')
    quantity = models.IntegerField(default=0)
    batch_start_date = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    is_batch_ended = models.BooleanField(default=False)
    is_updated = models.BooleanField(default=True)
    last_modified_date = models.DateTimeField(
        auto_now=False, blank=True, null=True)
    objects = MyManager()

    class Meta:
        db_table = 'Batch'

    def __str__(self):
        return self.id


class EndedBatchReport(models.Model):
    supplier = models.ForeignKey(Supplier)
    part = models.ForeignKey(Part)
    ended_batch = models.ForeignKey(Batch)
    file = models.FileField(upload_to=update_filename)

    class Meta:
        db_table = "EndedBatchReport"

    def __str__(self):
        return self.ended_batch.id


class SourceBatch(models.Model):
    """docstring for SourceBatch"""

    batch = models.ForeignKey(
        Batch, on_delete=models.CASCADE, related_name='source_batch',
        blank=True, null=True)
    source_batch_id = models.ForeignKey(
        Batch, on_delete=models.CASCADE,
        related_name='%(class)s_id', blank=True, null=True)

    class Meta:
        db_table = 'SourceBatch'


class InspectionSamples(models.Model):
    """docstring for InspectionSamples"""
    id = models.CharField(max_length=60, primary_key=True,
                          unique=True)  # Should be chaged to 'AutoField'
    serial_number = models.CharField(max_length=60)
    sample_category = models.CharField(max_length=60)
    date = models.DateTimeField(auto_now=True)
    has_remeasured = models.BooleanField(default=False)
    has_reworked = models.BooleanField(default=False)
    history = models.TextField()
    batch = models.ForeignKey(
        Batch, on_delete=models.CASCADE)
    is_updated = models.BooleanField(default=True)
    last_modified_date = models.DateTimeField(
        auto_now=False, blank=True, null=True)

    class Meta:
        db_table = 'InspectionSamples'

    def __str__(self):
        return self.id


class InspectionCharacteristics(models.Model):
    """docstring for InspectionCharacteristics"""
    id = models.CharField(max_length=60, primary_key=True,
                          unique=True)  # Should be chaged to 'AutoField'
    measured_value = models.CharField(max_length=60)
    mode_toggle = models.BooleanField(default=False)
    characteristics = models.ForeignKey(
        Characteristics, on_delete=models.CASCADE)
    inspection_samples = models.ForeignKey(
        InspectionSamples, on_delete=models.CASCADE,
        related_name='inspection_charateristics')

    class Meta:
        db_table = 'InspectionCharacteristics'
        unique_together = ('characteristics', 'inspection_samples')

    def __str__(self):
        return self.id


class AsnData(models.Model):
    asn = models.CharField(max_length=250)
    asn_quantity = models.IntegerField()
    vendor_code = models.CharField(max_length=250)
    part_code = models.CharField(max_length=250)
    invoice_number = models.CharField(max_length=250)
    plant_code = models.CharField(max_length=250)
    asn_date = models.DateField(blank=True, null=True)
    invoice_date = models.DateField(blank=True, null=True)

    class Meta:
        db_table = 'asn_data'

    def __str__(self):
        return self.invoice_number



class AsnBatch(models.Model):
    asn = models.ForeignKey(
        AsnData, on_delete=models.CASCADE)
    batch_number = models.CharField(max_length=250)
    batch_quantity = models.IntegerField()
    batch_date = models.DateField(blank=True, null=True)

    class Meta:
        db_table = 'asn_batch'


class AsnSourceBatchDetail(models.Model):
    batch = models.ForeignKey(Batch)
    lot_size = models.IntegerField()
    qualified = models.IntegerField()
    reworked = models.IntegerField()
    rejected = models.IntegerField()
    ppm = models.IntegerField()

    class Meta:
        managed = False

    def calculate_ppm(self, quantity, rejected):
        if rejected != 0:
            return (quantity / rejected) * 1000000
        else:
            return 0

    def get_batch_detail(self, batch):
        try:
            asn = AsnSourceBatchDetail()
            batch = Batch.objects.get(id=batch)
            inspection_samples = InspectionSamples.objects.filter(batch=batch)
            if len(inspection_samples) != 0:
                asn.lot_size = batch.quantity
                asn.qualified = inspection_samples.filter(
                    sample_category="Qualified"
                ).count()
                asn.reworked = inspection_samples.filter(
                    sample_category="Reworked"
                ).count()
                asn.rejected = inspection_samples.filter(
                    sample_category="Rejected"
                ).count()
                asn.ppm = self.calculate_ppm(
                    batch.quantity,
                    asn.reworked + asn.rejected
                )
                asn.batch = batch
                return asn
            else:
                return None
        except Batch.DoesNotExist:
            return None

    def get_source_batchs(self, batch):
        source_batch_list = SourceBatch.objects.filter(
            batch=batch).values_list("source_batch_id", flat=True)
        if len(source_batch_list)!=0:
            for source_batch in source_batch_list:
                return list(source_batch_list) + list(self.get_source_batchs(source_batch))
        else:
            return list(source_batch_list)

    def get_source_batchs_details(self, batch):
        batch_details = []
        batch_list = [batch] + self.get_source_batchs(batch)
        for batch in batch_list:
            detail = self.get_batch_detail(batch)
            if detail is not None:
                batch_details.append(detail)
        return batch_details
