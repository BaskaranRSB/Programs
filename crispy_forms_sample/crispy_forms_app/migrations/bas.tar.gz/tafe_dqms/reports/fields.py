from django import forms
from django.utils.translation import ugettext_lazy as _
from django.forms import ModelMultipleChoiceField, ModelChoiceField

from control_plan.models import Part, Supplier, Characteristics, Process, ControlPlan, PartSupplier
from inspection.models import Batch, InspectionSamples, InspectionCharacteristics
from authentication.models import DqmsUser
from login.models import SubScreen
from control_plan.forms import get_supplier_list, get_part_list
from tafe_dqms.custom_form_fields import GroupedModelChoiceField, GroupedModelMultiChoiceField


class SupplierChoiceField(ModelChoiceField):

    def label_from_instance(self, obj):
        return "%s-%s" % (obj.vendor_code, obj.vendor_name)


class SupplierMultiChoiceField(ModelMultipleChoiceField):

    def label_from_instance(self, obj):
        return "%s-%s" % (obj.vendor_code, obj.vendor_name)


class PartChoiceField(GroupedModelChoiceField):

    def label_from_instance(self, obj):
        return "%s" % obj.part


class PartMultiChoiceField(GroupedModelMultiChoiceField):

    def label_from_instance(self, obj):
        return "%s" % obj.part


class ControlPlanChoiceField(GroupedModelChoiceField):

    def label_from_instance(self, inprocess_version):
        return "Version - %s" % inprocess_version


class ControlPlanMultiChoiceField(GroupedModelMultiChoiceField):

    def label_from_instance(self, inprocess_version):
        return "Version - %s" % inprocess_version


class OperationChoiceField(GroupedModelChoiceField):

    def label_from_instance(self, obj):
        return "%s-%s" % (str(obj.process_id), obj.name)


class OperationMultiChoiceField(GroupedModelMultiChoiceField):

    def label_from_instance(self, obj):
        return "%s-%s" % (str(obj.process_id), obj.name)


class CharacteristicsChoiceField(GroupedModelChoiceField):

    def label_from_instance(self, obj):
	return "%s(%s)" % (obj.product, obj.product_spec)


class CharacteristicsMultiChoiceField(GroupedModelMultiChoiceField):

    def label_from_instance(self, obj):
	return "%s(%s)" % (obj.product, obj.product_spec)


class BatchNoChoiceField(GroupedModelChoiceField):

    def label_from_instance(self, obj):
	return "%s" % obj.id


class BatchNoMultiChoiceField(GroupedModelMultiChoiceField):

    def label_from_instance(self, obj):
        return "%s" % obj.id


fields_dict = {
    "supplier": {
        "single-select": SupplierChoiceField(
            queryset=Supplier.objects.all(),
            empty_label="Select Supplier",
            widget=forms.Select(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-live-search-placeholder": "Search Supplier"})
        ),
        "multi-select": SupplierMultiChoiceField(
            queryset=Supplier.objects.all(),
            widget=forms.SelectMultiple(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-actions-box": "true",
                       "data-live-search-placeholder": "Search Supplier",
                       "data-none-selected-text": "Select Supplier"})
        )
    },
    "part": {
        "single-select": PartChoiceField(
            queryset=PartSupplier.objects.none(),
            empty_label="Select Part",
            group_by_field='supplier',
            widget=forms.Select(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-live-search-placeholder": "Search Part"})
        ),
        "multi-select": PartMultiChoiceField(
            queryset=PartSupplier.objects.none(),
            group_by_field='supplier',
            widget=forms.SelectMultiple(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-actions-box": "true",
                       "data-live-search-placeholder": "Search Part",
                       "data-none-selected-text": "Select Part"})
        )
    },
    "control_plan": {
        "single-select": ControlPlanChoiceField(
            queryset=ControlPlan.objects.none(),
            empty_label="Select ControlPlan",
            group_by_field='part',
            widget=forms.Select(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-live-search-placeholder": "Search ControlPlan"})
        ),
        "multi-select": ControlPlanMultiChoiceField(
            queryset=ControlPlan.objects.none(),
            group_by_field='part',
            widget=forms.SelectMultiple(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-live-search-placeholder": "Search ControlPlan",
                       "data-none-selected-text": "Select ControlPlan"})
        )
    },
    "operations": {
        "single-select": OperationChoiceField(
            queryset=Process.objects.none(),
            empty_label="Select Operation",
            group_by_field='control_plan',
            widget=forms.Select(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-live-search-placeholder": "Search Operation"})
        ),
        "multi-select": OperationMultiChoiceField(
            queryset=Process.objects.none(),
            group_by_field='control_plan',
            widget=forms.SelectMultiple(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-live-search-placeholder": "Search Operation",
                       "data-none-selected-text": "Select Operation"})
        )
    },
    "characteristics": {
        "single-select": CharacteristicsChoiceField(
            queryset=Characteristics.objects.none(),
            empty_label="Select Characteristics",
            group_by_field='process',
            widget=forms.Select(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-live-search-placeholder": "Search Characteristics"})
        ),
        "multi-select": CharacteristicsMultiChoiceField(
            queryset=Characteristics.objects.none(),
            group_by_field='process',
            widget=forms.SelectMultiple(
                attrs={"class": "selectpicker",
                       "data-live-search": "true",
                       'data-width': '200px',
                       "data-actions-box": "true",
                       "data-live-search-placeholder": "Search Characteristics",
                       "data-none-selected-text": "Select Characteristics"})
        )
    },
    "batch_no": {
        "single-select": BatchNoChoiceField(
            queryset=Batch.objects.none(),
            empty_label="Select Batch",
            group_by_field='process',
            widget=forms.Select(
                attrs={"class": "selectpicker",
                       'data-width': '500px',
                       "data-live-search": "true",
                       "data-live-search-placeholder": "Search Batch", })
        ),
        "multi-select": BatchNoMultiChoiceField(
            queryset=Batch.objects.none(),
            group_by_field='process',
            widget=forms.SelectMultiple(
                attrs={"class": "selectpicker",
                       'data-width': '500px',
                       "data-live-search": "true",
                       "data-actions-box": "true",
                       "data-live-search-placeholder": "Search Batch",
                       "data-none-selected-text": "Select Batch"})
        )
    }
}
