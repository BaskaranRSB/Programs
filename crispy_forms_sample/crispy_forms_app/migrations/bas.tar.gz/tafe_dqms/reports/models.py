from __future__ import unicode_literals

from django.db import models
from django.db import connection, models


class MyManager(models.Manager):

    def raw_as_qs(self, raw_query, params=()):
        """Execute a raw query and return a QuerySet. The first column in the
            result set must be the id field for the model.
            :type raw_query: str | unicode
            :type params: tuple[T] | dict[str | unicode, T]
            :rtype: django.db.models.query.QuerySet
            """
        cursor = connection.cursor()
        try:
            cursor.execute(raw_query, params)
            return self.filter(id__in=(x[0] for x in cursor))
        finally:
            cursor.close()

# Create your models here.

class GrinData(models.Model):
    asn = models.CharField(max_length=250)
    grin_quantity = models.IntegerField()
    vendor_code = models.CharField(max_length=250)
    part_code = models.CharField(max_length=250)
    invoice_number = models.CharField(max_length=250)
    plant_code = models.CharField(max_length=250)
    date = models.DateField()

    class Meta:
        db_table = 'grin_data'

class GrinBatch(models.Model):
    asn = models.ForeignKey(
        GrinData, on_delete=models.CASCADE)
    batch_number = models.CharField(max_length=250)
    batch_quantity = models.IntegerField()    

    class Meta:
        db_table = 'grin_batch'

class PartsQtyRejection(models.Model):
    vendor_code = models.CharField(max_length=250)
    part_code = models.CharField(max_length=250)
    rejection_date = models.DateField()
    part_qty = models.IntegerField()
    part_type = models.CharField(max_length=250)
    notifn_no = models.CharField(max_length=250)

    class Meta:
        db_table = 'parts_qty_rejection'
