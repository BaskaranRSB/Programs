"""tafe_dqms URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from login.views import LoginView, logout_view, PermissionMatrix, set_permission

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^admin/permission_matrix/',
        PermissionMatrix.as_view(), name='permission_matrix'),
    url(r'^admin/set_permission/',
        set_permission, name='set_permission'),
    url(r'login/', LoginView.as_view(), name='login'),
    url(r'logout/', logout_view, name='logout'),
    url(r'^control/', include('control_plan.urls')),
    url(r'^inspection/', include('inspection.urls')),
    url(r'^reports/', include('reports.urls')),
    url(r'^organization/', include('organization.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
