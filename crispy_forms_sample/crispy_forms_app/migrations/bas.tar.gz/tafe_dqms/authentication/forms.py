from django import forms
from django.contrib.auth.forms import ReadOnlyPasswordHashField

from .models import DqmsUser


class DqmsUserCreationForm(forms.ModelForm):
    """A form for updating users. Includes all the fields on
    the user, but replaces the password field with admin's
    password hash display field.
    """
    password1 = forms.CharField(
        label="Type Password", widget=forms.PasswordInput)
    password2 = forms.CharField(
        label="Re-Type Password", widget=forms.PasswordInput)

    class Meta:
        model = DqmsUser
        fields = "__all__"

    def clean_password(self):
        password1 = self.cleaned_data['password1']
        password2 = self.cleaned_data['password2']
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Password does not match.")

    def save(self, commit=True):
        user = super(DqmsUserCreationForm, self).save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        user.save()
        return user


class DqmsUserChangeForm(forms.ModelForm):
    """A form for updating users. Includes all the fields on
    the user, but replaces the password field with admin's
    password hash display field.
    """
    password = ReadOnlyPasswordHashField()

    class Meta:
        model = DqmsUser
        fields = "__all__"

    def clean_password(self):
        return self.cleaned_data['password']
