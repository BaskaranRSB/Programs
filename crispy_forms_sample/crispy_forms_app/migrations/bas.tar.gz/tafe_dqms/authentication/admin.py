from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User, Group
from django.forms import ModelForm, PasswordInput
from django import forms

from .models import DqmsUser, LDAP
from .forms import DqmsUserCreationForm, DqmsUserChangeForm


LDAP_CHOICES = ((0, 'MS Active Directory'), (1, 'Opends'))


class LDAPForm(ModelForm):
    ldap_type = forms.ChoiceField(
        choices=LDAP_CHOICES
    )

    class Meta:
        model = LDAP
        fields = "__all__"
        widgets = {
            'password': PasswordInput()
        }


class LDAPAdmin(admin.ModelAdmin):
    form = LDAPForm


class DqmsUserAdmin(UserAdmin):
    form = DqmsUserChangeForm
    add_form = DqmsUserCreationForm

    list_display = ['user', 'ldap', ]
    ordering = ['user', ]

    fieldsets = (
        (None, {'fields': ('user', 'ldap',)}),
        ('Permissions', {'fields': (
            'is_staff', 'is_superuser', 'is_supplier_group', 'user_permissions',
        )}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('user', 'password1', 'password2')}
         ),
    )

    def get_form(self, request, obj=None, **kwargs):
        # Get form from original UserAdmin.
        form = super(DqmsUserAdmin, self).get_form(request, obj, **kwargs)
        if 'user_permissions' in form.base_fields:
            permissions = form.base_fields['user_permissions']
            permissions.queryset = permissions.queryset.exclude(
                content_type__app_label__in=[
                    'admin', 'contenttypes', 'authentication',
                    'sessions', 'table_refresh', 'reports',
                    'organization']
            ).exclude(
                content_type__model__in=[
                    'partsupplier', 'updatedtables', 'asn_staging',
                    'subscreen']
            ).exclude(
                codename__in=['add_mainscreen',
                              'change_mainscreen', 'delete_mainscreen']
            )
        return form

admin.site.unregister(Group)
admin.site.register(DqmsUser, DqmsUserAdmin)
admin.site.register(LDAP, LDAPAdmin)
